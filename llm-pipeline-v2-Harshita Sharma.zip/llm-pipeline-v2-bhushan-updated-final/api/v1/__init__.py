from fastapi import APIRouter
from api.v1.rag_routes import rag_router



api_router = APIRouter(prefix="/rag", tags=["rag"])

# Include all routers
api_router.include_router(rag_router)
