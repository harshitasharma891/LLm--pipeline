import json
import traceback
from typing import Any, Dict, List, Tuple

from src.logging import logger


class RAGPWithCoT:
    """
    RAG + Explainability Layer (client-rag aware).

    Uses ClientRAGChain fields when available:
      - retrieved_chunks: [{chunk_id, text, meta{source,page}, score, rerank_score?}, ...]
      - answer

    Produces:
      ✔ retrieval_explanation (per chunk with source/page/score)
      ✔ planning_explanation
      ✔ response_trace (per chunk mapped to answer)
      ✔ COT_response (final answer text)
    """

    def __init__(self, chain):
        self.chain = chain
        logger.info("Initialized RAGPWithCoT with chain.")

    # ---------------------------------------------------------
    # 0. Single-call invoke (avoid calling chain twice)
    # ---------------------------------------------------------
    def _invoke_once(self, query: str) -> Dict[str, Any]:
        logger.info("Invoking RAG chain once for query.")
        resp = self.chain.invoke({"input": query})
        if not isinstance(resp, dict):
            resp = {"answer": str(resp)}
        return resp

    # ---------------------------------------------------------
    # 1. Retrieve Relevant Documents/Chunks (client-rag aware)
    # ---------------------------------------------------------


    def retrieve_documents(
        self, chain_response: Dict[str, Any]
    ) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
        """
        Prefer retrieved_chunks.
        Adds filtering + ranking + topK so CoT stays meaningful.
        """
        chunks = chain_response.get("retrieved_chunks")
        reasoning_steps: List[Dict[str, Any]] = []

        # ---- Tunables (safe defaults) ----
        TOP_K = 6                 # show only top evidence
        MIN_SCORE = 0.10          # drop weak matches (adjust if needed)
        DROP_ZERO_SCORE = True    # remove score==0
        USE_RERANK_IF_PRESENT = True

        if isinstance(chunks, list) and chunks:
            logger.info("Building retrieval explanation from retrieved_chunks (filtered).")

            # normalize list of dicts only
            raw_chunks: List[Dict[str, Any]] = [c for c in chunks if isinstance(c, dict)]

            # choose ranking key: rerank_score if present else score
            def rank_key(c: Dict[str, Any]) -> float:
                if USE_RERANK_IF_PRESENT and "rerank_score" in c and c.get("rerank_score") is not None:
                    try:
                        return float(c.get("rerank_score") or 0.0)
                    except Exception:
                        return 0.0
                try:
                    return float(c.get("score") or 0.0)
                except Exception:
                    return 0.0

            # sort best-to-worst
            raw_chunks.sort(key=rank_key, reverse=True)

            # filter + dedupe
            seen_ids = set()
            filtered: List[Dict[str, Any]] = []

            for idx, c in enumerate(raw_chunks):
                meta = c.get("meta") or c.get("metadata") or {}
                if not isinstance(meta, dict):
                    meta = {}

                chunk_id = c.get("chunk_id") or c.get("id") or meta.get("chunk_id") or f"chunk_{idx}"
                if chunk_id in seen_ids:
                    continue
                seen_ids.add(chunk_id)

                # decide score for filtering
                score_val = 0.0
                try:
                    score_val = float(c.get("score") or 0.0)
                except Exception:
                    score_val = 0.0

                if DROP_ZERO_SCORE and score_val == 0.0:
                    continue
                if score_val < MIN_SCORE:
                    continue

                # build normalized chunk
                source = meta.get("source", "unknown")
                page = meta.get("page", meta.get("page_idx", meta.get("page_number")))

                text = str(c.get("text") or c.get("page_content") or c.get("content") or "")
                preview = text[:240]

                norm = {
                    "chunk_id": chunk_id,
                    "text": text,
                    "meta": {"source": source, "page": page},
                    "score": score_val,
                }

                # keep rerank_score only if not None
                if "rerank_score" in c and c.get("rerank_score") is not None:
                    try:
                        norm["rerank_score"] = float(c.get("rerank_score") or 0.0)
                    except Exception:
                        pass

                filtered.append(norm)

                reasoning_steps.append({
                    "document_id": source,
                    "page": page,
                    "chunk_id": chunk_id,
                    "key_passages": preview,
                    "score": score_val,
                    # omit rerank_score if not present
                    **({"rerank_score": norm.get("rerank_score")} if "rerank_score" in norm else {}),
                    "reasoning": "Selected as top evidence based on retrieval ranking (score threshold + top-K)."
                })

                if len(filtered) >= TOP_K:
                    break

            logger.debug(f"Chunks kept after filtering: {len(filtered)}")
            return filtered, reasoning_steps

        # ---- fallback: context documents (same as before) ----
        logger.warning("retrieved_chunks not found; falling back to context documents.")
        docs = chain_response.get("context", []) or []
        doc_like: List[Dict[str, Any]] = []

        for idx, doc in enumerate(docs):
            source = getattr(doc, "metadata", {}).get("source", "unknown")
            page = getattr(doc, "metadata", {}).get("page", None)
            text = getattr(doc, "page_content", "") or ""
            preview = text[:240]

            doc_like.append({
                "chunk_id": f"doc_{idx}",
                "text": text,
                "meta": {"source": source, "page": page},
                "score": None,
            })

            reasoning_steps.append({
                "document_id": source,
                "page": page,
                "chunk_id": f"doc_{idx}",
                "key_passages": preview,
                "score": None,
                "reasoning": "Selected because it appears in the retrieved context for the query."
            })

            if len(doc_like) >= TOP_K:
                break

        return doc_like, reasoning_steps


    # ---------------------------------------------------------
    # 2. Plan Response Strategy
    # ---------------------------------------------------------
    def plan_response(
        self, query: str, retrieved_items: List[Dict[str, Any]]
    ) -> Tuple[str, List[Dict[str, Any]]]:
        logger.info("Planning response strategy...")

        n = len(retrieved_items)
        if n == 0:
            strategy = "no_context_fallback"
        elif n > 3:
            strategy = "multi_source_integration"
        else:
            strategy = "direct_answer"

        planning = [{
            "strategy": strategy,
            "considered_alternatives": [
                "direct_answer",
                "synthesized_response",
                "multi_source_integration",
                "no_context_fallback",
            ],
            "reasoning": (
                f"Selected '{strategy}' based on retrieved evidence count ({n}) "
                f"and expected query complexity."
            ),
        }]

        logger.debug(f"Response strategy selected: {strategy}")
        return strategy, planning

    # ---------------------------------------------------------
    # 3. Generate Final Response + Traceability
    # ---------------------------------------------------------
    def generate_response(
        self,
        chain_response: Dict[str, Any],
        retrieved_items: List[Dict[str, Any]],
        strategy: str
    ) -> Tuple[str, List[Dict[str, Any]]]:
        logger.info("Generating final response + traceability...")

        answer_raw = chain_response.get("answer", "") or ""
        final_answer = str(answer_raw).split("Answer:")[-1].strip()

        response_trace: List[Dict[str, Any]] = []
        for item in retrieved_items:
            meta = item.get("meta") or {}
            source = (meta.get("source") if isinstance(meta, dict) else None) or "unknown"
            page = meta.get("page") if isinstance(meta, dict) else None
            chunk_id = item.get("chunk_id")
            text = str(item.get("text") or "")
            preview = text[:160]

            response_trace.append({
                "document_id": source,
                "page": page,
                "chunk_id": chunk_id,
                "mapped_content": preview,
                "reasoning": "Included because it contributes relevant evidence supporting the answer."
            })

        logger.debug(f"Answer preview: {final_answer[:120]}")
        logger.debug(f"Trace items: {len(response_trace)}")

        return final_answer, response_trace

    # ---------------------------------------------------------
    # 4. End-to-End Pipeline
    # ---------------------------------------------------------
    def run_ragp_with_cot(self, query: str) -> str:
        logger.info(f"Running RAG + explainability pipeline for query: '{query}'")

        try:
            chain_response = self._invoke_once(query)

            retrieved_items, retrieval_explanation = self.retrieve_documents(chain_response)

            strategy, planning_explanation = self.plan_response(query, retrieved_items)

            final_response, response_trace = self.generate_response(
                chain_response=chain_response,
                retrieved_items=retrieved_items,
                strategy=strategy
            )

            logger.info("RAG + explainability completed successfully.")
            return json.dumps({
                "status": "success",
                "retrieval_explanation": retrieval_explanation,
                "planning_explanation": planning_explanation,
                "response_trace": response_trace,
                "COT_response": final_response
            }, indent=2, ensure_ascii=False)

        except Exception as e:
            logger.error(f"Error in pipeline: {str(e)}")
            logger.debug(traceback.format_exc())

            return json.dumps({
                "status": "error",
                "error_message": str(e),
                "traceback": traceback.format_exc()
            }, indent=2, ensure_ascii=False)



