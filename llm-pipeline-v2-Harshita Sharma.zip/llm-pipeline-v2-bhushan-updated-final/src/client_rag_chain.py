# client_rag_chain.py
from typing import Any, Dict, Optional, List
import json
import httpx
import pandas as pd
import os

from src.logging import logger

try:
    from langchain_core.documents import Document
except Exception:
    try:
        from langchain.schema import Document
    except Exception:
        from dataclasses import dataclass

        @dataclass
        class Document:
            page_content: str


DEFAULT_PROMPT_TEMPLATE = "{system}\n\nContext:\n{context}\n\nQuestion:\n{question}\n\nAnswer:"


class ClientRAGChain:
    """
    Client adapter:
      - POST /rag/query
      - GET  /dataset/read

    ✅ Robust for observability:
      - retrieved_chunks normalized + score present
      - prompt_info normalized + prompt_text present
      - prompt_truncation supported (new from server rag.py)
      - reranking enabled/disabled auto-detected

    ✅ Dataset API robustness:
      - Splits large dataset/read documents into smaller chunks for testset generation
    """

    def __init__(self, base_url: str, user_id: str, timeout: float = 300.0):
        base = (base_url or "").rstrip("/")
        if base.endswith("/rag/query"):
            base = base[:-10]

        self.base_url = base
        self.rag_url = f"{self.base_url}/rag/query"
        self.dataset_url = f"{self.base_url}/dataset/read"
        self.user_id = user_id
        self.timeout = float(timeout)

    # ---------------- helpers ----------------

    def _extract_answer(self, raw: Any) -> str:
        if isinstance(raw, dict):
            for k in ("answer", "final_answer", "result", "response", "output_text"):
                if k in raw and raw[k] is not None:
                    return str(raw[k]).strip()
            return json.dumps(raw, ensure_ascii=False)
        return str(raw).strip()

    def _extract_context_text(self, raw: Any) -> str:
        if isinstance(raw, dict):
            ctx = raw.get("context") or raw.get("retrieved_context") or ""
            if isinstance(ctx, (list, dict)):
                return json.dumps(ctx, ensure_ascii=False)
            return str(ctx)
        return ""

    def _context_to_documents(self, ctx_text: str) -> List[Document]:
        if not ctx_text:
            return []
        return [Document(page_content=ctx_text)]

    def _ensure_meta(self, meta: Any) -> Dict[str, Any]:
        m = meta if isinstance(meta, dict) else {}
        # Keep citation-friendly keys stable
        m.setdefault("source", m.get("file", "unknown"))
        if "page" not in m and "page_idx" in m:
            m["page"] = m.get("page_idx")
        if "page" not in m and "page_number" in m:
            m["page"] = m.get("page_number")
        return m

    def _normalize_chunks(self, chunks: Any) -> List[Dict[str, Any]]:
        """
        Normalizes retrieved_chunks so your 3 observability techniques always work.

        Expected minimal per chunk:
          - chunk_id
          - text
          - meta (with source/page if available)
          - score (float)
          - optional: rerank_score (float)
        """
        out: List[Dict[str, Any]] = []
        if not isinstance(chunks, list):
            return out

        for c in chunks:
            if not isinstance(c, dict):
                continue
            cc = dict(c)

            # normalize meta/metadata
            cc["meta"] = self._ensure_meta(cc.get("meta") or cc.get("metadata") or {})

            # normalize text field
            if "text" not in cc:
                if "page_content" in cc:
                    cc["text"] = cc.get("page_content")
                elif "content" in cc:
                    cc["text"] = cc.get("content")
                else:
                    cc["text"] = ""

            # chunk id
            cc.setdefault("chunk_id", cc.get("id") or cc["meta"].get("chunk_id"))

            # score: ensure always float
            try:
                cc["score"] = float(cc.get("score", 0.0) or 0.0)
            except Exception:
                cc["score"] = 0.0

            # rerank_score normalize if present
            if "rerank_score" in cc:
                try:
                    cc["rerank_score"] = float(cc.get("rerank_score") or 0.0)
                except Exception:
                    cc["rerank_score"] = 0.0

            out.append(cc)

        return out

    def _detect_reranking(self, raw: Dict[str, Any], chunks: List[Dict[str, Any]]) -> bool:
        rr = raw.get("reranking")
        if isinstance(rr, dict) and isinstance(rr.get("enabled"), bool):
            return bool(rr["enabled"])
        # fallback: if any chunk has rerank_score
        return any(("rerank_score" in c) for c in chunks)

    def _extract_prompt_info(self, raw: Dict[str, Any]) -> Dict[str, Any]:
        pi = raw.get("prompt_info") or {}
        if not isinstance(pi, dict):
            pi = {}

        # robust defaults even if server sends minimal prompt info
        pi.setdefault("prompt_template", DEFAULT_PROMPT_TEMPLATE)
        pi.setdefault("system_prompt", "")
        pi.setdefault("prompt_text", "")
        pi.setdefault("model_name", "")
        pi.setdefault("prompt_version", pi.get("prompt_version", ""))

        return pi

    def _extract_prompt_truncation(self, raw: Dict[str, Any]) -> Dict[str, Any]:
        """
        New field returned by updated server rag.py.
        Keep stable defaults so PromptSnapshot technique never breaks.
        """
        pt = raw.get("prompt_truncation") or {}
        if not isinstance(pt, dict):
            pt = {}

        pt.setdefault("enabled", False)
        pt.setdefault("policy", "unknown")
        pt.setdefault("max_prompt_chars", None)
        pt.setdefault("template_overhead_chars", None)
        pt.setdefault("available_context_chars", None)
        pt.setdefault("context_chars_before", None)
        pt.setdefault("context_chars_after", None)
        pt.setdefault("truncated_chars", 0)
        pt.setdefault("was_truncated", False)
        pt.setdefault("reason", "unknown")

        return pt

    # ---------------- dataset chunking helpers ----------------

    def _split_text(self, text: str, chunk_size: int = 1500, overlap: int = 150) -> List[str]:
        """
        Split text into smaller overlapping chunks (character-based).
        This prevents huge dataset/read documents (e.g., 50k chars) from breaking testset generation.
        """
        t = (text or "").strip()
        if not t:
            return []

        chunk_size = max(200, int(chunk_size))
        overlap = max(0, min(int(overlap), chunk_size - 1))

        chunks: List[str] = []
        start = 0
        n = len(t)

        while start < n:
            end = min(n, start + chunk_size)
            chunks.append(t[start:end])
            if end >= n:
                break
            start = max(0, end - overlap)

        return chunks

    def _dataset_to_chunks_df(
        self,
        docs: List[Dict[str, Any]],
        chunk_size: int = 1500,
        overlap: int = 150,
        max_chunks: Optional[int] = None,
    ) -> pd.DataFrame:
        rows: List[Dict[str, Any]] = []

        for d in docs:
            if not isinstance(d, dict):
                continue

            content = str(d.get("content", "") or "")
            source = d.get("source", "api_dataset")
            page = d.get("page_idx", d.get("page", d.get("page_number")))

            parts = self._split_text(content, chunk_size=chunk_size, overlap=overlap)

            for p in parts:
                rows.append({"chunk": p, "source": source, "page_idx": page})
                if max_chunks is not None and len(rows) >= max_chunks:
                    break

            if max_chunks is not None and len(rows) >= max_chunks:
                break

        return pd.DataFrame(rows, columns=["chunk", "source", "page_idx"])

    # ---------------- invoke ----------------

    def invoke(self, inp: Dict[str, Any]) -> Dict[str, Any]:
        query = inp.get("input") or inp.get("query") or inp.get("question") or inp.get("q")
        if not query:
            raise ValueError("Expected {'input': <query>} or {'query': <query>}")

        user_id = inp.get("user_id") or self.user_id
        include_timings = bool(inp.get("include_timings", True))

        payload = {"user_id": user_id, "query": query, "include_timings": include_timings}

        with httpx.Client(timeout=self.timeout) as client:
            resp = client.post(self.rag_url, json=payload)

            if resp.status_code == 404:
                logger.warning("No documents found for user_id=%s", user_id)
                raw = {
                    "answer": "No documents found for this user_id",
                    "retrieved_context": [],
                    "retrieved_chunks": [],
                    "prompt_info": {},
                    "prompt_truncation": {},
                    "reranking": {"enabled": False},
                    "timings": None,
                    "error": "No documents found",
                    "no_documents_found": True,
                }
            else:
                resp.raise_for_status()
                raw = resp.json()

        if not isinstance(raw, dict):
            raw = {"answer": raw}

        chunks = self._normalize_chunks(raw.get("retrieved_chunks", []))
        reranking_enabled = self._detect_reranking(raw, chunks)
        prompt_info = self._extract_prompt_info(raw)
        prompt_truncation = self._extract_prompt_truncation(raw)

        return {
            "user_id": user_id,
            "query": query,
            "answer": self._extract_answer(raw),
            "context": self._context_to_documents(self._extract_context_text(raw)),
            "retrieved_context": self._extract_context_text(raw),
            "retrieved_chunks": chunks,
            "prompt_info": prompt_info,
            "prompt_truncation": prompt_truncation,
            "reranking": {"enabled": reranking_enabled},
            "timings": raw.get("timings") if isinstance(raw.get("timings"), dict) else None,
            "raw": raw,
        }

    # ---------------- dataset ----------------

    def read_dataset(self, user_id: Optional[str] = None) -> Dict[str, Any]:
        uid = user_id or self.user_id
        logger.info("Reading dataset | user_id=%s", uid)

        try:
            with httpx.Client(timeout=self.timeout) as client:
                resp = client.get(self.dataset_url, params={"user_id": uid})
                resp.raise_for_status()
                return resp.json()
        except Exception:
            logger.exception("Dataset read failed")
            raise

    def read_dataset_df(self, user_id: Optional[str] = None) -> pd.DataFrame:
        """
        Reads /dataset/read and returns a DataFrame with columns:
          - chunk
          - source
          - page_idx

        ✅ Important: splits very large documents into many smaller chunks so
        TestDatasetManager can generate Q/A reliably (prevents "No usable Q/A pairs").
        """
        data = self.read_dataset(user_id)
        docs = data.get("documents", [])

        if not docs:
            return pd.DataFrame(columns=["chunk", "source", "page_idx"])

        # Tunables (optional)
        chunk_size = int(os.getenv("DATASET_API_CHUNK_SIZE", "1500"))
        overlap = int(os.getenv("DATASET_API_CHUNK_OVERLAP", "150"))
        max_chunks_env = os.getenv("DATASET_API_MAX_CHUNKS", "").strip()
        max_chunks = int(max_chunks_env) if max_chunks_env.isdigit() else None

        df = self._dataset_to_chunks_df(
            docs=docs,
            chunk_size=chunk_size,
            overlap=overlap,
            max_chunks=max_chunks,
        )

        logger.info(
            "Dataset API chunking | docs=%s -> chunks=%s | chunk_size=%s overlap=%s",
            len(docs), len(df), chunk_size, overlap
        )

        return df


