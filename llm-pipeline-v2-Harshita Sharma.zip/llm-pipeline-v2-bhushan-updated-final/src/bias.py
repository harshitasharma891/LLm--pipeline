import os
import re
import torch
import json
from transformers import pipeline, AutoTokenizer, AutoModelForSequenceClassification
from src.logging import logger

from dotenv import load_dotenv
load_dotenv()


class UnbiasProcessor:
    def __init__(self, chain):
        self.chain = chain
        self.model_save_path = "src/unbias_model"
        self.classifier = self.load_bias_classifier()
        self.pipeline = self.setup_rag_pipeline()

        # ---------------------------
        # OpenAI fallback (lazy init)
        # ---------------------------
        self._openai_client = None
        self._openai_model = os.getenv("OPENAI_FALLBACK_MODEL", "gpt-4o-mini")

    # -----------------------------------------------------------
    # Load / Download Bias Classifier
    # -----------------------------------------------------------
    def load_bias_classifier(self):
        try:
            if not os.path.exists(self.model_save_path):
                logger.info("Downloading UnBIAS classifier model...")

                tokenizer = AutoTokenizer.from_pretrained("newsmediabias/UnBIAS-classifier")
                model = AutoModelForSequenceClassification.from_pretrained("newsmediabias/UnBIAS-classifier")

                tokenizer.save_pretrained(self.model_save_path)
                model.save_pretrained(self.model_save_path)
                logger.info("Model downloaded & saved locally.")

            tokenizer = AutoTokenizer.from_pretrained(self.model_save_path)
            model = AutoModelForSequenceClassification.from_pretrained(self.model_save_path)

            classifier = pipeline(
                "text-classification",
                model=model,
                tokenizer=tokenizer,
                device=0 if torch.cuda.is_available() else -1,
                truncation=True,
                max_length=512
            )

            logger.info("UnBIAS classifier loaded successfully.")
            return classifier

        except Exception as e:
            logger.error(f"Error loading UnBIAS classifier: {e}", exc_info=True)
            # IMPORTANT: return None -> will trigger OpenAI fallback in process_query
            return None

    # -----------------------------------------------------------
    # Setup RAG Pipeline
    # -----------------------------------------------------------
    def setup_rag_pipeline(self):
        try:
            if not self.chain:
                raise ValueError("RAG chain object NOT provided.")

            logger.info("RAG pipeline initialized successfully.")
            return self.chain

        except Exception as e:
            logger.error(f"Error setting up RAG pipeline: {e}", exc_info=True)
            return None

    # -----------------------------------------------------------
    # Robust JSON Parser for LLM Responses
    # -----------------------------------------------------------
    def _parse_json_response(self, response_text: str):
        """
        Robustly parse LLM JSON, even if wrapped in ```json fences or with extra text.

        Steps:
        - Strip markdown code fences ```...```
        - Remove optional 'json' language tag
        - Extract substring from first '{' to last '}'
        - json.loads on that substring
        """
        text = response_text.strip()

        # Remove markdown code fences if present: ```json\n{...}\n```
        if text.startswith("```"):
            parts = text.split("```")
            if len(parts) >= 2:
                text = parts[1]
            text = text.strip()

        # Remove 'json' tag if present at the top
        if text.lower().startswith("json"):
            text = text[4:].lstrip()

        start = text.find("{")
        end = text.rfind("}")
        if start == -1 or end == -1:
            raise ValueError("No JSON object found in response text")

        json_str = text[start:end + 1]
        return json.loads(json_str)

    # -----------------------------------------------------------
    # Section Extractor – Legacy Fallback
    # -----------------------------------------------------------
    def extract_section(self, text, section_name):
        """
        Legacy fallback parser.

        Supports:
        1. JSON-formatted LLM output (when parse_json_response isn't used)
        2. Old-style text with headings like:
           'Biased Terms:', 'Explanations:', 'Neutral Version:'
        """
        try:
            try:
                parsed = json.loads(text)
                if section_name == "Biased Terms":
                    return parsed.get("biased_terms", [])
                if section_name == "Explanations":
                    return parsed.get("explanations", [])
                if section_name == "Neutral Version":
                    return parsed.get("neutral_version", "")
            except Exception:
                pass

            if section_name not in text:
                return "Not found"

            section = text.split(f"{section_name}:")[1].strip()
            next_headers = ["Biased Terms:", "Explanations:", "Neutral Version:"]

            for header in next_headers:
                if header != f"{section_name}:" and header in section:
                    section = section.split(header)[0].strip()
                    break

            return section.strip()

        except Exception:
            return "Analysis format error"

    # -----------------------------------------------------------
    # OpenAI Fallback Helpers (private, UI-safe)
    # -----------------------------------------------------------
    def _get_openai_client(self):
        """
        Lazy init OpenAI client. Uses env:
          - OPENAI_API_KEY
          - OPENAI_BASE_URL (optional; for proxy/OpenAI-compatible)
        """
        if self._openai_client is not None:
            return self._openai_client

        try:
            from openai import OpenAI
        except Exception as e:
            logger.error(f"OpenAI SDK not available for fallback: {e}", exc_info=True)
            return None

        api_key = "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"
        base_url = os.getenv("OPENAI_BASE_URL")

        if not api_key:
            logger.error("OPENAI_API_KEY not set. Cannot use OpenAI fallback.")
            return None

        try:
            if base_url:
                self._openai_client = OpenAI(api_key=api_key, base_url=base_url)
            else:
                self._openai_client = OpenAI(api_key=api_key)
            return self._openai_client
        except Exception as e:
            logger.error(f"Failed to initialize OpenAI client: {e}", exc_info=True)
            return None

    def _openai_bias_analyze(self, text: str):
        """
        Returns a dict matching the expected schema:
        {
          "biased_terms": [],
          "explanations": [],
          "neutral_version": ""
        }
        """
        client = self._get_openai_client()
        if client is None:
            raise RuntimeError("OpenAI client not available")

        prompt = f"""
Analyze the following text for bias and return output ONLY in the following JSON format.

VERY IMPORTANT:
- Do NOT wrap the JSON in markdown code fences.
- Do NOT include ```json or ``` anywhere.
- Respond with RAW JSON only.

Expected JSON schema:
{{
  "biased_terms": [],
  "explanations": [],
  "neutral_version": ""
}}

Text: {text}

Rules:
- Identify biased or judgmental language (words/phrases).
- Explain why each term is problematic in plain language.
- Rewrite the text neutrally while preserving meaning.
- If there is no bias, return empty arrays and neutral_version equal to the original text.
""".strip()

        try:
            resp = client.chat.completions.create(
                model=self._openai_model,
                messages=[
                    {"role": "system", "content": "You output strictly valid raw JSON only."},
                    {"role": "user", "content": prompt},
                ],
                temperature=0,
            )
            content = (resp.choices[0].message.content or "").strip()
            return self._parse_json_response(content)
        except Exception as e:
            logger.error(f"OpenAI fallback bias analysis failed: {e}", exc_info=True)
            raise

    def _openai_bias_label_score(self, analysis: dict):
        """
        Simple bias label + score from analysis.
        Score is heuristic (0..1).
        """
        try:
            biased_terms = analysis.get("biased_terms", [])
            n = len(biased_terms) if isinstance(biased_terms, list) else 0
            if n <= 0:
                return {"bias_label": "Not Biased", "bias_score": 0.0}
            # heuristic: more terms => higher score, capped
            score = min(0.95, 0.35 + (0.12 * n))
            label = "Biased" if score < 0.75 else "Highly Biased"
            return {"bias_label": label, "bias_score": float(score)}
        except Exception:
            return {"bias_label": "Unknown", "bias_score": None}

    # -----------------------------------------------------------
    # Analyze bias & neutralize text using RAG
    # -----------------------------------------------------------
    def analyze_and_neutralize(self, text, bias_result):
        if not self.pipeline:
            logger.error("RAG pipeline not initialized.")
            return None

        try:
            is_biased = any(
                res.get("label") in ["Highly Biased", "Biased"]
                for res in (bias_result or [])
                if isinstance(res, dict)
            )

            if not is_biased:
                return None

            analysis_prompt = f"""
Analyze the following text for bias and return output ONLY in the following JSON format.

VERY IMPORTANT:
- Do NOT wrap the JSON in markdown code fences.
- Do NOT include ```json or ``` anywhere.
- Respond with RAW JSON only.

Expected JSON schema:
{{
  "biased_terms": [],
  "explanations": [],
  "neutral_version": ""
}}

Text: {text}

Rules:
- Identify biased or judgmental language.
- Explain why each term is problematic.
- Rewrite the text neutrally.
"""

            rag_output = self.pipeline.invoke({"input": analysis_prompt})
            response_text = rag_output.get("answer", "").strip()

            try:
                parsed = self._parse_json_response(response_text)
                biased_terms = parsed.get("biased_terms", [])
                explanations = parsed.get("explanations", [])
                neutral_version = parsed.get("neutral_version", "")
            except Exception as e:
                logger.error(f"LLM did NOT return valid JSON. Falling back to extractor. Error: {e}")
                biased_terms = self.extract_section(response_text, "Biased Terms")
                explanations = self.extract_section(response_text, "Explanations")
                neutral_version = self.extract_section(response_text, "Neutral Version")

            logger.info("Bias analysis completed by RAG.")

            return {
                "original": text,
                "analysis_raw": response_text,
                "neutral_version": neutral_version,
                "biased_terms": biased_terms,
                "explanations": explanations
            }

        except Exception as e:
            logger.error(f"Bias neutralization failed: {e}", exc_info=True)
            return None

    # -----------------------------------------------------------
    # Bias Scoring from Classifier
    # -----------------------------------------------------------
    def analyze_answer(self, answer):
        try:
            if not self.classifier:
                # OpenAI fallback score (no classifier: return Unknown; score will be computed in process_query)
                return {"bias_label": "Fallback(OpenAI)", "bias_score": None}

            result = self.classifier(answer)[0]
            logger.info(f"Bias classification result: {result}")

            return {
                "bias_label": result.get("label", "Unknown"),
                "bias_score": result.get("score", None)
            }

        except Exception as e:
            logger.error(f"Bias score extraction failed: {e}", exc_info=True)
            return {
                "bias_label": "Error",
                "bias_score": None
            }

    # -----------------------------------------------------------
    # Main Query Processor (RAG + Bias)
    # -----------------------------------------------------------
    def process_query(self, question):
        if not self.pipeline:
            logger.error("RAG pipeline not initialized.")
            return None

        try:
            logger.info(f"Processing query: {question}")

            rag_response = self.pipeline.invoke({"input": question})
            full_answer = rag_response.get("answer", "")
            rag_answer = full_answer.split("Answer:")[-1].strip()

            # ---------------------------
            # Primary: UnBIAS classifier
            # Fallback: OpenAI gpt-4o-mini
            # ---------------------------
            bias_result = None
            bias_analysis = None
            bias_score_info = None

            if self.classifier:
                try:
                    bias_result = self.classifier(rag_answer)
                    bias_analysis = self.analyze_and_neutralize(rag_answer, bias_result)
                    bias_score_info = self.analyze_answer(rag_answer)
                except Exception as e:
                    logger.error(f"UnBIAS classifier path failed, switching to OpenAI fallback: {e}", exc_info=True)
                    self.classifier = None  # prevent repeated crashes
            else:
                logger.warning("UnBIAS classifier not available. Using OpenAI fallback for bias detection.")

            # OpenAI fallback path (only if classifier missing/failed)
            if not self.classifier:
                try:
                    analysis = self._openai_bias_analyze(rag_answer)
                    bias_analysis = {
                        "original": rag_answer,
                        "analysis_raw": json.dumps(analysis, ensure_ascii=False),
                        "neutral_version": analysis.get("neutral_version", ""),
                        "biased_terms": analysis.get("biased_terms", []),
                        "explanations": analysis.get("explanations", []),
                    }
                    bias_score_info = self._openai_bias_label_score(analysis)

                    # keep output key consistent with earlier structure
                    bias_result = [
                        {
                            "label": bias_score_info.get("bias_label", "Fallback(OpenAI)"),
                            "score": bias_score_info.get("bias_score", None),
                            "provider": "openai_fallback",
                            "model": self._openai_model,
                        }
                    ]
                except Exception as e:
                    logger.error(f"OpenAI fallback also failed: {e}", exc_info=True)
                    bias_result = [{"label": "Error", "score": None}]
                    bias_analysis = None
                    bias_score_info = {"bias_label": "Error", "bias_score": None}

            logger.info("Query processing completed.")

            return {
                # "question": question,
                # "rag_answer": rag_answer,
                "unbias_result": bias_result,
                "bias_analysis": bias_analysis,
                "bias_score_info": bias_score_info
            }

        except Exception as e:
            logger.error(f"Error processing query: {e}", exc_info=True)
            return None

    # -----------------------------------------------------------
    # Optional Logging
    # -----------------------------------------------------------
    def log_info(self, msg):
        logger.info(msg)

    def log_error(self, msg):
        logger.error(msg)

