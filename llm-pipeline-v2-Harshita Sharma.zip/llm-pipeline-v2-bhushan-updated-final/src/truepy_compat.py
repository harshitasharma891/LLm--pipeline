# src/truepy_compat.py

"""
Compatibility patch for truepy with modern cryptography versions.

Problem:
    truepy internally uses the old public_key.verifier(...) API.

Why it fails:
    Newer cryptography versions removed signer/verifier APIs.

Fix:
    Replace truepy's old verification flow with public_key.verify(...).
"""

import base64

from truepy import License

from cryptography import x509
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import padding, rsa, dsa, ec


def _load_certificate(certificate):
    """
    Convert certificate bytes into a cryptography certificate object.

    Supports:
        - PEM certificate bytes
        - DER certificate bytes
        - Already-loaded certificate object
    """

    # If certificate is already parsed, return it
    if hasattr(certificate, "public_key"):
        return certificate

    # Convert string certificate to bytes
    if isinstance(certificate, str):
        certificate = certificate.encode("utf-8")

    # Try PEM certificate first
    try:
        return x509.load_pem_x509_certificate(certificate)
    except ValueError:
        pass

    # Try DER certificate if PEM fails
    return x509.load_der_x509_certificate(certificate)


def _get_hash_algorithm(digest_name: str):
    """
    Convert digest name into cryptography hash object.

    Example:
        SHA1   -> hashes.SHA1()
        SHA256 -> hashes.SHA256()
    """

    digest_name = (digest_name or "SHA1").upper().replace("-", "")

    hash_mapping = {
        "SHA1": hashes.SHA1,
        "SHA224": hashes.SHA224,
        "SHA256": hashes.SHA256,
        "SHA384": hashes.SHA384,
        "SHA512": hashes.SHA512,
    }

    if digest_name not in hash_mapping:
        raise ValueError(f"Unsupported license signature digest: {digest_name}")

    return hash_mapping[digest_name]()


def patch_truepy_cryptography_api():
    """
    Patch truepy License.verify so it works with modern cryptography.

    Safe to call multiple times.
    """

    # Avoid patching again and again
    if getattr(License, "_modern_crypto_patch_applied", False):
        return

    def verify_compat(self, certificate):
        """
        Replacement for truepy's old License.verify method.
        """

        # 1. Load certificate and get public key
        certificate_obj = _load_certificate(certificate)
        public_key = certificate_obj.public_key()

        # 2. Decode base64 signature from license
        signature_value = self.signature

        if isinstance(signature_value, str):
            signature_value = signature_value.encode("ascii")

        signature = base64.b64decode(signature_value)

        # 3. Get exact encoded license content
        message = self.encoded

        if isinstance(message, str):
            message = message.encode("ascii")

        # 4. Detect digest algorithm
        digest_name = getattr(self, "_signature_digest", None)

        if not digest_name:
            signature_algorithm = getattr(self, "signature_algorithm", "SHA1withRSA")
            digest_name = signature_algorithm.split("with")[0]

        hash_algorithm = _get_hash_algorithm(digest_name)

        try:
            # RSA certificate verification
            if isinstance(public_key, rsa.RSAPublicKey):
                public_key.verify(
                    signature,
                    message,
                    padding.PKCS1v15(),
                    hash_algorithm,
                )

            # DSA certificate verification
            elif isinstance(public_key, dsa.DSAPublicKey):
                public_key.verify(
                    signature,
                    message,
                    hash_algorithm,
                )

            # ECDSA certificate verification
            elif isinstance(public_key, ec.EllipticCurvePublicKey):
                public_key.verify(
                    signature,
                    message,
                    ec.ECDSA(hash_algorithm),
                )

            else:
                raise ValueError(
                    f"Unsupported public key type for license verification: {type(public_key)}"
                )

        except InvalidSignature as exc:
            raise ValueError("License signature is invalid.") from exc

    # Apply monkey patch
    License.verify = verify_compat
    License._modern_crypto_patch_applied = True