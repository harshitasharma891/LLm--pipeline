import os
import sys
import logging

LOG_FORMAT = '[%(asctime)s: %(levelname)s: %(module)s: %(lineno)d: %(message)s]'
LOG_DIR = os.path.join("results", "logs")
LOG_FILE = os.path.join(LOG_DIR, "logging.log")

os.makedirs(LOG_DIR, exist_ok=True)

def _create_logger(name: str = "LLM-pipeline-Logger") -> logging.Logger:
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)
    logger.propagate = False

    formatter = logging.Formatter(LOG_FORMAT)

    if not logger.handlers:
        # File handler
        fh = logging.FileHandler(LOG_FILE, encoding="utf-8")
        fh.setLevel(logging.INFO)
        fh.setFormatter(formatter)

        # Console handler
        ch = logging.StreamHandler(sys.stdout)
        ch.setLevel(logging.INFO)
        ch.setFormatter(formatter)

        logger.addHandler(fh)
        logger.addHandler(ch)

    return logger


# ✅ SINGLE GLOBAL LOGGER INSTANCE
logger = _create_logger()







# import os
# import sys
# import logging

# log_info = '[%(asctime)s: %(levelname)s: %(module)s: %(lineno)d: %(message)s]'
# log_dir = 'results/logs'
# log_path = os.path.join(log_dir, 'logging.log')
# os.makedirs(log_dir, exist_ok=True)

# logging.basicConfig(
#     level=logging.INFO,
#     format=log_info,
#     handlers=[
#         logging.FileHandler(log_path),
#         logging.StreamHandler(sys.stdout)
#     ]
# )

# logger = logging.getLogger("LLM-pipeline-Logger")