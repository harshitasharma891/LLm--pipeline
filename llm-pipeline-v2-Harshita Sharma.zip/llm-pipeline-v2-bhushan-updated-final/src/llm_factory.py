# src/llm_factory.py
import os
from typing import Optional, Any, Dict
from dotenv import load_dotenv
from langchain_openai import ChatOpenAI
from langchain_ollama import ChatOllama
from transformers import AutoTokenizer, AutoModelForCausalLM, pipeline
from langchain_huggingface import HuggingFacePipeline, ChatHuggingFace
from src.logging import logger

load_dotenv()


def _mask(s: Optional[str], keep: int = 4) -> str:
    """Mask secrets for logs."""
    if not s:
        return ""
    s = str(s)
    if len(s) <= keep:
        return "*" * len(s)
    return ("*" * (len(s) - keep)) + s[-keep:]


def _clean_kwargs(kwargs: Dict[str, Any]) -> Dict[str, Any]:
    """Remove/mask any sensitive fields before logging."""
    out = dict(kwargs or {})
    for k in list(out.keys()):
        lk = k.lower()
        if any(x in lk for x in ["key", "token", "secret", "password", "authorization"]):
            out[k] = "***"
    return out


def build_chat_model(
    provider: str = "openai",
    model: str = "gpt-4o-mini",
    temperature: float = 0.5,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
    max_new_tokens: int = 256,
    **kwargs: Any,
):
    """
    Build a LangChain chat model from different providers.

    Supported:
      - OpenAI: provider="openai"
      - OpenAI-compatible servers (vLLM / LM Studio / etc.): provider="openai_compatible"
      - Ollama (open-source local): provider="ollama"
      - HuggingFace local transformers (open-source): provider="huggingface"
    """
    provider_norm = (provider or "openai").strip().lower()
    model = (model or "").strip()

    # prefer explicit args, then env
    env_openai_key = "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"
    env_openai_base = os.getenv("OPENAI_BASE_URL")
    env_ollama_base = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")

    # Choose effective params per provider (without leaking secrets)
    effective_base_url = base_url
    if provider_norm in {"openai", "openai_compatible", "vllm", "lmstudio"}:
        effective_base_url = base_url or env_openai_base
    elif provider_norm == "ollama":
        effective_base_url = base_url or env_ollama_base

    # logger.info(
    #     "build_chat_model called | provider=%s | model=%s | temp=%.3f | max_new_tokens=%d | base_url=%s | kwargs=%s",
    #     provider_norm,
    #     model,
    #     float(temperature),
    #     int(max_new_tokens),
    #     effective_base_url or "",
    #     _clean_kwargs(kwargs),
    # )

    try:
        # -------- OpenAI / Compatible --------
        if provider_norm in {"openai", "openai_compatible", "vllm", "lmstudio"}:
            

            # If user passed api_key explicitly, use it; else env
            effective_key = api_key or env_openai_key

            if not effective_key:
                logger.warning(
                    "KEY missing ",
                )
            else:
                logger.debug("Using  key", _mask(effective_key))

            chat = ChatOpenAI(
                model=model,
                temperature=temperature,
                api_key=effective_key,
                base_url=effective_base_url,  # optional for compatible servers
            )

            
            return chat

        # -------- Ollama --------
        if provider_norm == "ollama":
            

            ollama_kwargs = dict(kwargs)

            if "format" not in ollama_kwargs:
                # Try to force JSON mode (helps a lot when generating strict JSON)
                ollama_kwargs["format"] = "json"

            # keep the caller's model unless you want to hardcode
            effective_model = model or "llama3:8b"

            logger.info(
                "Creating Ollama chat model | model=%s | base_url=%s | kwargs=%s",
                effective_model,
                effective_base_url,
                _clean_kwargs(ollama_kwargs),
            )

            chat = ChatOllama(
                model=effective_model,
                temperature=temperature,
                base_url=effective_base_url,
                **ollama_kwargs,
            )

            logger.info(
                "Chat model created | provider=ollama | class=%s | model=%s | base_url=%s",
                chat.__class__.__name__,
                effective_model,
                effective_base_url,
            )
            return chat

        # -------- HuggingFace (local transformers) --------
        if provider_norm in {"huggingface", "hf", "transformers"}:
            

            if not model:
                raise ValueError("For HuggingFace provider, 'model' must be a valid repo id or local path.")

            logger.info(
                "Loading HuggingFace model | model=%s | device_map=auto | max_new_tokens=%d",
                model,
                int(max_new_tokens),
            )

            tokenizer = AutoTokenizer.from_pretrained(model)
            hf_model = AutoModelForCausalLM.from_pretrained(model, device_map="auto")

            do_sample = float(temperature) > 0
            gen_pipe = pipeline(
                "text-generation",
                model=hf_model,
                tokenizer=tokenizer,
                max_new_tokens=int(max_new_tokens),
                do_sample=do_sample,
                temperature=float(temperature) if do_sample else None,
            )

            llm = HuggingFacePipeline(pipeline=gen_pipe)
            chat = ChatHuggingFace(llm=llm)

            logger.info(
                "Chat model created | provider=huggingface | class=%s | model=%s | do_sample=%s",
                chat.__class__.__name__,
                model,
                do_sample,
            )
            return chat

        # -------- Unknown Provider --------
        raise ValueError(
            f"Unknown provider='{provider_norm}'. Use one of: openai | openai_compatible | ollama | huggingface"
        )

    except Exception:
        logger.exception(
            "build_chat_model failed | provider=%s | model=%s | base_url=%s",
            provider_norm,
            model,
            effective_base_url or "",
        )
        raise

