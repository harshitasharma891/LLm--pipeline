#OLD

import os
import re
import json
import hashlib
import math
from datetime import datetime
from typing import Optional, Tuple, List, Union, Dict, Any
import numpy as np
import pandas as pd
import fitz  # PyMuPDF
import nltk
import docx  # python-docx
import pypandoc
from bs4 import BeautifulSoup

from src.config import LLM_CONFIG

from langchain_core.prompts import PromptTemplate
from langchain_core.documents import Document
from openai import LengthFinishReasonError
from src.llm_factory import build_chat_model
from concurrent.futures import ThreadPoolExecutor, as_completed
from difflib import SequenceMatcher

# Optional clustering for domain-independent topic discovery
try:
    from sklearn.cluster import MiniBatchKMeans
    from sklearn.metrics import pairwise_distances_argmin_min
except Exception:
    MiniBatchKMeans = None
    pairwise_distances_argmin_min = None

# Optional semantic embeddings
try:
    from sentence_transformers import SentenceTransformer
except Exception:
    SentenceTransformer = None

# Optional: if your repo has src.logging.logger we will use it,
# otherwise fallback to print-based logger.
try:
    from src.logging import logger  # type: ignore
except Exception:
    class _PrintLogger:
        def info(self, msg): print("[INFO]", msg)
        def warning(self, msg): print("[WARN]", msg)
        def error(self, msg, exc_info=False): print("[ERROR]", msg)
        def debug(self, msg): print("[DEBUG]", msg)
    logger = _PrintLogger()

nltk.download("punkt", quiet=True)

# ============================
# CONFIGURATION
# ============================
SCHEMA_VERSION = os.getenv("TESTSET_SCHEMA_VERSION", "v2.0")
OUTPUT_DIR = os.getenv("TESTSET_OUTPUT_DIR", "results/Testset/")
os.makedirs(OUTPUT_DIR, exist_ok=True)

DATASET_COLUMNS = ["question", "ground_truth", "source", "page_idx", "source_hash"]

# Smart chunking config
SMART_CHUNK_MAX_CHARS = int(os.getenv("SMART_CHUNK_MAX_CHARS", "1800"))
SMART_CHUNK_MIN_CHARS = int(os.getenv("SMART_CHUNK_MIN_CHARS", "500"))
SEMANTIC_SIM_THRESHOLD = float(os.getenv("SEMANTIC_SIM_THRESHOLD", "0.72"))
TOKEN_GUARD_CHARS = int(os.getenv("TOKEN_GUARD_CHARS", "2200"))
SECTION_MERGE_GAP = int(os.getenv("SECTION_MERGE_GAP", "180"))

# QA generation config
MAX_QA_PER_CHUNK = int(os.getenv("MAX_QA_PER_CHUNK", "2"))
MIN_QA_PER_CHUNK = 1

# Domain-independent topic discovery + production cap config
# Final generated question set will never cross 2000 rows.
TESTSET_MAX_ROWS = min(int(os.getenv("TESTSET_MAX_ROWS", "2000")), 2000)
TESTSET_TARGET_ROWS = min(
    int(os.getenv("TESTSET_TARGET_ROWS", "500")),
    TESTSET_MAX_ROWS,
    2000,
)
TOPIC_DISCOVERY_ENABLED = os.getenv("TOPIC_DISCOVERY_ENABLED", "true").lower() in {"1", "true", "yes"}
TOPIC_BALANCED_GENERATION = os.getenv("TOPIC_BALANCED_GENERATION", "true").lower() in {"1", "true", "yes"}

# Optional semantic topic filter. Works for any domain because it uses embeddings, not hardcoded categories.
# Examples:
# TESTSET_TOPIC_FILTER_TEXT="loan eligibility and interest rates"
# TESTSET_TOPIC_FILTER_TEXT="patient discharge process"
# TESTSET_TOPIC_FILTER_TEXT="contract termination clauses"
TESTSET_TOPIC_FILTER_TEXT = os.getenv("TESTSET_TOPIC_FILTER_TEXT", "").strip()
TOPIC_FILTER_SIM_THRESHOLD = float(os.getenv("TOPIC_FILTER_SIM_THRESHOLD", "0.35"))
TOPIC_FILTER_TOP_K = int(os.getenv("TOPIC_FILTER_TOP_K", "100"))

# Dynamic topic clustering settings. No domain-specific topic names are hardcoded.
MIN_TOPIC_CLUSTERS = int(os.getenv("MIN_TOPIC_CLUSTERS", "5"))
MAX_TOPIC_CLUSTERS = int(os.getenv("MAX_TOPIC_CLUSTERS", "50"))
TOPIC_LABEL_SAMPLE_CHUNKS = int(os.getenv("TOPIC_LABEL_SAMPLE_CHUNKS", "3"))

# Production quality gates for generated Q/A pairs.
MIN_GT_WORDS = int(os.getenv("MIN_GT_WORDS", "8"))
MIN_QUESTION_WORDS = int(os.getenv("MIN_QUESTION_WORDS", "5"))
QA_REPAIR_ENABLED = os.getenv("QA_REPAIR_ENABLED", "true").lower() in {"1", "true", "yes"}
QA_REPAIR_MAX_CHARS = int(os.getenv("QA_REPAIR_MAX_CHARS", "2600"))
SEMANTIC_QUESTION_DEDUP_ENABLED = os.getenv("SEMANTIC_QUESTION_DEDUP_ENABLED", "true").lower() in {"1", "true", "yes"}
SEMANTIC_QUESTION_DEDUP_THRESHOLD = float(os.getenv("SEMANTIC_QUESTION_DEDUP_THRESHOLD", "0.88"))
FUZZY_QUESTION_DEDUP_THRESHOLD = float(os.getenv("FUZZY_QUESTION_DEDUP_THRESHOLD", "0.88"))
REJECT_UNSUPPORTED_NUMERIC_VALUES = os.getenv("REJECT_UNSUPPORTED_NUMERIC_VALUES", "true").lower() in {"1", "true", "yes"}
REQUIRE_PAGE_IDX = os.getenv("REQUIRE_PAGE_IDX", "false").lower() in {"1", "true", "yes"}
REJECT_TEMPLATE_GROUND_TRUTH = os.getenv("REJECT_TEMPLATE_GROUND_TRUTH", "true").lower() in {"1", "true", "yes"}
REJECT_ANSWER_LEAK_IN_QUESTION = os.getenv("REJECT_ANSWER_LEAK_IN_QUESTION", "true").lower() in {"1", "true", "yes"}
REJECT_CIRCULAR_ANSWERS = os.getenv("REJECT_CIRCULAR_ANSWERS", "true").lower() in {"1", "true", "yes"}

# Coverage mode: production generation must cover all discovered meaning-wise topics,
# not just a few high-confidence chunks. This is domain-independent.
COVERAGE_MODE = os.getenv("COVERAGE_MODE", "true").lower() in {"1", "true", "yes"}
MIN_QA_PER_TOPIC = int(os.getenv("MIN_QA_PER_TOPIC", "3"))
MAX_QA_PER_TOPIC = int(os.getenv("MAX_QA_PER_TOPIC", "8"))
MIN_CHUNKS_PER_TOPIC = int(os.getenv("MIN_CHUNKS_PER_TOPIC", "1"))
MAX_CHUNKS_PER_TOPIC = int(os.getenv("MAX_CHUNKS_PER_TOPIC", "6"))
# Dynamic per-chunk generation cap used only in coverage mode.
# Keep this reasonably small to avoid noisy questions from a single chunk.
MAX_DYNAMIC_QA_PER_CHUNK = int(os.getenv("MAX_DYNAMIC_QA_PER_CHUNK", "10"))
# Generate more candidates than target because validation/dedup removes weak rows.
COVERAGE_OVERSAMPLE_FACTOR = float(os.getenv("COVERAGE_OVERSAMPLE_FACTOR", "1.5"))
# For small documents, use every meaningful chunk to avoid missing sections.
COVERAGE_SMALL_DOC_CHUNK_LIMIT = int(os.getenv("COVERAGE_SMALL_DOC_CHUNK_LIMIT", "80"))


# ============================
# UTILITY FUNCTIONS
# ============================
def compute_text_hash(text: str) -> str:
    return hashlib.sha256((text or "").encode("utf-8")).hexdigest()


def normalize_question_for_dedup(question: str) -> str:
    """
    Normalize questions so exact and near-duplicate questions collapse together.

    Examples:
    - What is the purpose of GST?
    - What is the objective of GST?

    Both become similar enough to deduplicate.
    """
    q = (question or "").lower().strip()

    # Remove punctuation/symbol noise.
    q = re.sub(r"[^\w\s]", " ", q)

    # Normalize whitespace.
    q = re.sub(r"\s+", " ", q).strip()

    # Normalize common intent synonyms that often create duplicate Q/A rows.
    synonym_patterns = [
        (r"\bobjective\b", "purpose"),
        (r"\bobjectives\b", "purpose"),
        (r"\baim\b", "purpose"),
        (r"\baims\b", "purpose"),
        (r"\bgoal\b", "purpose"),
        (r"\bgoals\b", "purpose"),
        (r"\breason\b", "purpose"),
        (r"\breasons\b", "purpose"),
        (r"\bmeaning\b", "definition"),
        (r"\bdefine\b", "what is"),
        (r"\bexplain\b", "what is"),
        (r"\btell me about\b", "what is"),
    ]

    for pattern, replacement in synonym_patterns:
        q = re.sub(pattern, replacement, q)

    q = re.sub(r"\s+", " ", q).strip()
    return q


def make_question_dedup_key(source: str, question: str) -> str:
    """
    Create a stable dedup key using source + normalized question only.

    Do not include the answer or passage hash here. If answer/passage is included,
    the same question with a different answer will survive as a duplicate.
    """
    normalized_q = normalize_question_for_dedup(question)
    raw_key = f"{source or ''}::{normalized_q}"
    return hashlib.sha256(raw_key.encode("utf-8")).hexdigest()


def is_near_duplicate_question(q1: str, q2: str, threshold: float = 0.92) -> bool:
    q1_norm = normalize_question_for_dedup(q1)
    q2_norm = normalize_question_for_dedup(q2)

    if not q1_norm or not q2_norm:
        return False

    if q1_norm == q2_norm:
        return True

    return SequenceMatcher(None, q1_norm, q2_norm).ratio() >= threshold


def resp_to_text(resp) -> str:
    if resp is None:
        return ""
    if isinstance(resp, str):
        return resp
    if hasattr(resp, "content"):
        return resp.content or ""
    return str(resp)


def extract_first_json_object(text: str) -> dict:
    if not text or not text.strip():
        raise ValueError("Empty response text")

    cleaned = re.sub(r"```(?:json)?", "", text, flags=re.IGNORECASE)
    cleaned = cleaned.replace("```", "").strip()

    start = cleaned.find("{")
    if start == -1:
        raise ValueError("No JSON object start '{' found")

    depth = 0
    in_string = False
    escape = False

    for i in range(start, len(cleaned)):
        ch = cleaned[i]

        if in_string:
            if escape:
                escape = False
            elif ch == "\\":
                escape = True
            elif ch == '"':
                in_string = False
        else:
            if ch == '"':
                in_string = True
            elif ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    candidate = cleaned[start:i + 1]
                    return json.loads(candidate)

    raise ValueError("Could not find a complete JSON object")


def looks_like_noise(text: str) -> bool:
    if not text:
        return True
    t = text.strip()
    if len(t) < 120:
        return True
    letters = sum(ch.isalpha() for ch in t)
    if letters / max(len(t), 1) < 0.40:
        return True
    lines = [ln.strip() for ln in t.splitlines() if ln.strip()]
    if len(lines) >= 5:
        uniq_ratio = len(set(lines)) / len(lines)
        if uniq_ratio < 0.45:
            return True
    return False


def clamp(n: int, lo: int, hi: int) -> int:
    return max(lo, min(hi, n))


def normalize_whitespace(text: str) -> str:
    text = text.replace("\x00", " ")
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def approx_token_count(text: str) -> int:
    # rough estimate: 1 token ≈ 4 chars in English-ish text
    return max(1, len(text) // 4)


def _norm_for_value_match(text: str) -> str:
    t = str(text or "").lower()
    t = t.replace("–", "-").replace("—", "-").replace("−", "-")
    t = t.replace(",", "")
    t = re.sub(r"\s+", " ", t)
    return t.strip()


def extract_numeric_like_values(text: str) -> List[str]:
    """
    Extract values that are dangerous to hallucinate: money, percentages, dates, and numbers.
    Used to block prompt/example leakage such as unsupported credit-score values.
    """
    t = str(text or "")
    patterns = [
        r"[₹£$€]\s?\d[\d,]*(?:\.\d+)?(?:\s?(?:lakhs?|crores?|million|billion|thousand))?",
        r"\b\d+(?:\.\d+)?\s?%",
        r"\b\d{1,2}\s+(?:january|february|march|april|may|june|july|august|september|october|november|december|jan|feb|mar|apr|jun|jul|aug|sep|sept|oct|nov|dec)\s+\d{4}\b",
        r"\b\d{4}[-/]\d{1,2}[-/]\d{1,2}\b",
        r"\b\d+(?:\.\d+)?(?:\s?(?:months?|years?|days?|points?|per annum|pa|p\.a\.|lakhs?|crores?|million|billion|thousand))\b",
        r"\b\d{2,4}\b",
    ]
    values: List[str] = []
    for pat in patterns:
        for m in re.finditer(pat, t, flags=re.I):
            val = _norm_for_value_match(m.group(0))
            if val and val not in values:
                values.append(val)
    return values


def unsupported_values_in_answer(answer: str, passage: str) -> List[str]:
    """Return numeric/date/currency values that appear in the answer but not in the source passage."""
    passage_norm = _norm_for_value_match(passage)
    unsupported = []
    for val in extract_numeric_like_values(answer):
        val_norm = _norm_for_value_match(val)
        relaxed = val_norm.replace(" ", "")
        passage_relaxed = passage_norm.replace(" ", "")
        if val_norm not in passage_norm and relaxed not in passage_relaxed:
            unsupported.append(val)
    return unsupported


def is_value_only_answer(answer: str) -> bool:
    a = str(answer or "").strip().strip('"').strip("'")
    if not a:
        return True

    if a.lower() in {"yes", "no", "true", "false", "n/a", "na", "none"}:
        return True

    words = re.findall(r"[A-Za-zÀ-ÖØ-öø-ÿ]+", a)
    if len(words) <= 3:
        value_patterns = [
            r"^[₹£$€]\s?\d[\d,]*(?:\.\d+)?(?:\s?(?:lakhs?|crores?|million|billion|thousand))?$",
            r"^\d+(?:\.\d+)?\s?%$",
            r"^\d{1,2}\s+[A-Za-z]+\s+\d{4}$",
            r"^\d+(?:\.\d+)?(?:\s?(?:months?|years?|days?|points?))?$",
            r"^[A-Z][A-Za-z0-9&.,'’\- ]{1,80}$",
        ]
        if any(re.match(p, a, flags=re.I) for p in value_patterns):
            return True

    return False


def is_question_too_vague(question: str) -> bool:
    q = str(question or "").strip()
    if not q:
        return True

    words = re.findall(r"\w+", q)
    if len(words) < MIN_QUESTION_WORDS:
        return True

    vague_patterns = [
        r"^what is the tone of the passage\??$",
        r"^what kind of language is used in the passage\??$",
        r"^what is the passage about\??$",
        r"^what is mentioned in the passage\??$",
        r"^what is the eligibility criteria for applying\??$",
        r"^what was the fy\d{4} profit\??$",
        r"^what was the reason for the award\??$",
        r"purpose of the sentence that starts with",
        r"^what is the purpose of the sentence",
        r"^what is the author's opinion of the passage",
        r"^what is the main subject of the passage",
        r"^which of the following",
    ]
    return any(re.match(p, q, flags=re.I) for p in vague_patterns)


def has_complete_sentence_shape(answer: str) -> bool:
    a = str(answer or "").strip()
    if not a or not re.match(r"^[A-Z0-9₹£$€]", a):
        return False
    if not re.search(r"[.!?]$", a):
        return False

    words = re.findall(r"[A-Za-zÀ-ÖØ-öø-ÿ]+", a)
    if len(words) < MIN_GT_WORDS:
        return False

    # Reject obvious unfinished fragments such as
    # "She was uncomfortable with some of the unethical and unlawful."
    if re.search(r"\b(?:of|and|or|with|to|for|from|about|that|because|including)\.?$", a.strip(), flags=re.I):
        return False

    # Require at least one likely finite/action verb. This catches fragments like
    # "Gains on short-term equity investments..." and "False accusations of bullying...".
    finite_verb_pattern = (
        r"\b(?:is|are|was|were|be|been|being|has|have|had|do|does|did|"
        r"reported|stated|described|continued|shifted|planned|expected|purchased|"
        r"incurred|held|made|served|received|confirmed|removed|wrote|became|"
        r"awarded|approved|conducted|deployed|included|involved|raised|"
        r"resigned|recommence|recommenced|amounted|totaled|totalled|showed|"
        r"suggests|indicates|means|requires|required|provided)\b"
    )
    if not re.search(finite_verb_pattern, a, flags=re.I):
        return False

    return True


def answer_word_count(answer: str) -> int:
    return len(re.findall(r"[A-Za-zÀ-ÖØ-öø-ÿ0-9₹£$€%]+", str(answer or "")))


def coerce_page_idx(value: Any) -> Optional[int]:
    """Normalize page index values so CSV does not silently get blank/NaN page_idx."""
    if value is None:
        return None
    try:
        if isinstance(value, float) and np.isnan(value):
            return None
    except Exception:
        pass
    text = str(value).strip()
    if not text or text.lower() in {"none", "nan", "null"}:
        return None
    m = re.search(r"\d+", text)
    if not m:
        return None
    try:
        n = int(m.group(0))
        return n if n > 0 else None
    except Exception:
        return None


def sanitize_ground_truth_text(answer: str) -> str:
    """Remove artificial repair-template wording and normalize grammar/punctuation."""
    a = str(answer or "").strip()
    a = a.strip('"').strip("'").strip()

    template_phrases = [
        r",?\s*according to the provided passage",
        r",?\s*according to the passage",
        r",?\s*according to the provided context",
        r",?\s*according to the context",
        r",?\s*according to the source text",
        r",?\s*according to the source",
        r",?\s*as stated in the provided passage",
        r",?\s*as mentioned in the provided passage",
        r",?\s*from the provided passage",
    ]
    for pat in template_phrases:
        a = re.sub(pat, "", a, flags=re.I)

    # Remove bad generic wrapper: The answer to 'Question' is X.
    m = re.match(r"^the answer to ['\"]?.+?['\"]? is (.+)$", a, flags=re.I)
    if m:
        a = m.group(1).strip()

    # Normalize month capitalization in simple date answers.
    month_map = {m.lower(): m for m in [
        "January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"
    ]}
    for low, proper in month_map.items():
        a = re.sub(rf"\b{low}\b", proper, a, flags=re.I)

    # Common repair artifacts.
    # IMPORTANT: do not blindly lowercase proper nouns; repair only known bad patterns.
    a = re.sub(r"\bon\s+Around\b", "around", a)
    a = re.sub(r"\bwas\s+Around\b", "was around", a)
    a = re.sub(r"\bis\s+Around\b", "is around", a)
    a = re.sub(r"\bwas\s+hardy plc\b", "was Hardy plc", a, flags=re.I)
    a = re.sub(r"\bwas\s+telit\s+IOT\s+Solutions\s+Limited\b", "was Telit IOT Solutions Limited", a, flags=re.I)
    a = re.sub(r"\btelit\s+IOT\s+Solutions\s+Limited\b", "Telit IOT Solutions Limited", a, flags=re.I)
    a = re.sub(r"\benterprise\s+Investment\s+Scheme\b", "Enterprise Investment Scheme", a, flags=re.I)
    a = re.sub(r"\bms\s+L\s+Cameron-Peck\b", "Ms L Cameron-Peck", a, flags=re.I)
    a = re.sub(r"^the number\s+ordinary shares\b", "There were ordinary shares", a, flags=re.I)
    a = re.sub(r"^There were ordinary shares of ([^,]+) were in issue and fully paid .* was ([0-9,]+)", r"There were \2 ordinary shares of \1 in issue and fully paid after redenomination into pounds sterling", a, flags=re.I)
    a = re.sub(r"^There were ordinary shares of ([^,]+) each were in issue and fully paid .* was ([0-9,]+)", r"There were \2 ordinary shares of \1 each in issue and fully paid after redenomination into pounds sterling", a, flags=re.I)
    a = re.sub(r"^the amount of money that\s+(.+?)\s+received", r"The amount \1 received", a, flags=re.I)
    a = re.sub(r"\s+,", ",", a)
    a = re.sub(r",\s*\.", ".", a)
    a = re.sub(r"\s+\.", ".", a)
    a = re.sub(r"\.{2,}$", ".", a)
    a = re.sub(r"\s+", " ", a).strip()

    if a and not re.search(r"[.!?]$", a):
        a += "."
    if a:
        a = a[0].upper() + a[1:]
    return a


def has_template_ground_truth(answer: str) -> bool:
    a = str(answer or "")
    return bool(re.search(
        r"according to the (provided )?(passage|context|source)|as stated in the provided passage|from the provided passage|^\s*the answer to\s+['\"]?",
        a,
        flags=re.I,
    ))


def has_speculative_or_meta_answer(answer: str) -> bool:
    """Reject answers that are not direct production-grade ground truths."""
    a = str(answer or "").strip()
    if not a:
        return True

    bad_patterns = [
        r"not explicitly mentioned",
        r"could be found",
        r"could be inferred",
        r"however,? the passage states",
        r"so,? the .+ could",
        r"toxicity detectors",
        r"groundedness checks",
        r"something concrete to catch",
        r"^to give .+detectors",
        r"^demonstrating\b",
        r"^false accusations\b",
        r"^gains on\b",
        r"^an employee\b",
        r"^the status of .+ was hmrc eis approved\.?$",
    ]
    if any(re.search(p, a, flags=re.I) for p in bad_patterns):
        return True

    # Reject dangling quote/fragments that end after adjectives or conjunctions.
    if re.search(r"(?:unethical|unlawful|approved|mentioned)\.?$", a, flags=re.I) and answer_word_count(a) < 14:
        return True

    return False


def _answer_core(answer: str) -> str:
    """Extract the likely value/core phrase from a full-sentence answer."""
    a = sanitize_ground_truth_text(answer)
    a = re.sub(r"[.!?]+$", "", a).strip()

    # Prefer text after the last copular verb for simple generated answers.
    parts = re.split(r"\b(?:is|was|are|were|received|reported|expected|confirmed)\b", a, flags=re.I)
    if len(parts) > 1:
        core = parts[-1].strip(" :,-")
    else:
        core = a

    # Remove common leading determiners but preserve names/numbers.
    core = re.sub(r"^(?:to be|as|the|a|an)\s+", "", core, flags=re.I).strip()
    core = re.sub(r"\s+", " ", core)
    return core.strip()


def answer_appears_inside_question(question: str, answer: str) -> bool:
    """Reject rows where the answer was already embedded in the question."""
    q = str(question or "").lower()
    core = _answer_core(answer)
    core_clean = re.sub(r"[^a-z0-9₹£$€% ]", " ", core.lower())
    core_clean = re.sub(r"\s+", " ", core_clean).strip()
    q_clean = re.sub(r"[^a-z0-9₹£$€% ]", " ", q)
    q_clean = re.sub(r"\s+", " ", q_clean).strip()

    if not core_clean:
        return False

    core_words = [w for w in core_clean.split() if len(w) > 1]
    if len(core_words) <= 6 and core_clean in q_clean:
        return True

    # Name/entity leakage: answer is mostly a proper name already present in the question.
    raw_core_words = re.findall(r"[A-Z][A-Za-z'’\-]+", core)
    if raw_core_words and len(core_words) <= 8:
        name = " ".join(raw_core_words).lower()
        if len(name.split()) >= 2 and name in q_clean:
            return True

    return False


def is_circular_or_uninformative_answer(question: str, answer: str) -> bool:
    """Reject tautological answers like 'the investment offering was an investment offering'."""
    q_norm = normalize_question_for_dedup(question)
    a = sanitize_ground_truth_text(answer)
    core = _answer_core(a)
    core_norm = normalize_question_for_dedup(core)

    if not core_norm:
        return True

    # Generic placeholders are not production-grade ground truths.
    generic_bad = {
        "an investment offering", "investment offering", "a large controlling interest",
        "large controlling interest", "a fact", "the fact", "a passage", "the passage",
        "the company", "the person", "the subject", "not mentioned", "not explicitly mentioned",
    }
    if core_norm in generic_bad:
        return True

    # Circular: the answer core is already the same concept as the question and adds no value.
    if core_norm in q_norm and answer_word_count(a) <= 14 and not extract_numeric_like_values(a):
        significant = [w for w in core_norm.split() if len(w) > 3]
        if significant and all(w in q_norm for w in significant):
            return True

    # Pattern: "The X was X" / "The X is X".
    m = re.match(r"^the\s+(.+?)\s+(?:is|was|are|were)\s+(?:a|an|the)?\s*(.+)$", a.lower().rstrip("."))
    if m:
        left = normalize_question_for_dedup(m.group(1))
        right = normalize_question_for_dedup(m.group(2))
        if right and (right in left or left in right):
            return True

    return False


def is_bad_question_form(question: str) -> bool:
    q = str(question or "").strip().lower()
    bad_patterns = [
        r"^which of the following",
        r"not mentioned in the passage",
        r"main subject of the passage",
        r"author'?s opinion of the passage",
        r"what is the passage'?s opinion",
        r"what is the author'?s opinion of the passage",
        r"what is the tone of the passage",
        r"what kind of language is used in the passage",
        r"purpose of the sentence that starts with",
        r"what is the purpose of the sentence",
        r"yearly profit and loss figure",
        r"what was the investment offering that hmrc approved",
        r"what was the name of the person who .* named",
        r"what was the nature of the business practices",
        r"what was the outcome of .* reporting .* to hmrc",
    ]
    return any(re.search(p, q, flags=re.I) for p in bad_patterns)


def is_page_idx_required_for_source(source: str) -> bool:
    return REQUIRE_PAGE_IDX and str(source or "").lower().endswith(".pdf")


def ensure_dataset_schema(df: pd.DataFrame) -> pd.DataFrame:
    for c in DATASET_COLUMNS:
        if c not in df.columns:
            df[c] = None
    return df[DATASET_COLUMNS]


# ============================
# AUDIT LOGGER
# ============================
class AuditLogger:
    def __init__(self, auditor: str, output_dir: str = OUTPUT_DIR):
        self.auditor = auditor
        self.output_dir = output_dir

    def log(self, source_type: str):
        log_entry = {
            "timestamp": datetime.utcnow().isoformat(),
            "supplied_by": self.auditor,
            "source_type": source_type,
            "schema_version": SCHEMA_VERSION,
        }
        logger.info(f"🧾 Audit log created: {log_entry}")
        with open(os.path.join(self.output_dir, "audit_log.json"), "w", encoding="utf-8") as f:
            json.dump(log_entry, f, indent=2)


# ============================
# DATASET QUALITY SCORER
# ============================
class DatasetQualityScorer:
    def score(self, df: pd.DataFrame) -> dict:
        logger.info("📊 Scoring dataset quality...")

        if df.empty:
            scores = {
                "non_empty_questions": 0.0,
                "non_empty_answers": 0.0,
                "avg_answer_length": 0.0,
                "overall_score": 0.0,
            }
            logger.info(f"✅ Dataset quality scores: {scores}")
            return scores

        q = df.get("question", pd.Series([], dtype=str)).astype(str)
        a = df.get("ground_truth", pd.Series([], dtype=str)).astype(str)

        scores = {
            "non_empty_questions": float(q.str.len().gt(10).mean()) if len(q) else 0.0,
            "non_empty_answers": float(a.str.len().gt(20).mean()) if len(a) else 0.0,
            "avg_answer_length": float(a.str.len().mean()) if len(a) else 0.0,
        }
        scores["overall_score"] = round(
            (scores["non_empty_questions"] + scores["non_empty_answers"]) / 2, 3
        )

        logger.info(f"✅ Dataset quality scores: {scores}")
        return scores


# ============================
# SMART CHUNKING
# ============================
class SmartChunker:
    def __init__(self):
        self.max_chars = SMART_CHUNK_MAX_CHARS
        self.min_chars = SMART_CHUNK_MIN_CHARS
        self.semantic_threshold = SEMANTIC_SIM_THRESHOLD
        self.token_guard_chars = TOKEN_GUARD_CHARS

        self.embedding_model = None
        if SentenceTransformer is not None:
            try:
                model_name = os.getenv("SMART_CHUNK_EMBED_MODEL", "sentence-transformers/all-MiniLM-L6-v2")
                self.embedding_model = SentenceTransformer(model_name)
                logger.info(f"Loaded semantic chunk model: {model_name}")
            except Exception as e:
                logger.warning(f"Semantic model unavailable, fallback to rule-based split: {e}")

    # -------------------------
    # Heading detection
    # -------------------------
    def is_heading(self, line: str) -> bool:
        s = (line or "").strip()
        if not s:
            return False

        if len(s) > 120:
            return False

        # numbered headings: 1 / 1.1 / Section 2 / Chapter 3
        if re.match(r"^(section|chapter|part|appendix)\s+\w+", s, flags=re.I):
            return True
        if re.match(r"^\d+(\.\d+)*[\)\.]?\s+[A-Z]", s):
            return True

        # short uppercase headings
        letters = [c for c in s if c.isalpha()]
        if letters:
            upper_ratio = sum(c.isupper() for c in letters) / len(letters)
            if upper_ratio > 0.8 and len(s.split()) <= 10:
                return True

        # title-like short line without ending punctuation
        if len(s.split()) <= 10 and not re.search(r"[.:;!?]$", s):
            alpha_ratio = sum(ch.isalpha() for ch in s) / max(len(s), 1)
            if alpha_ratio > 0.6:
                return True

        return False

    # -------------------------
    # Build section blocks
    # -------------------------
    def split_into_sections(self, text: str) -> List[Dict[str, str]]:
        text = normalize_whitespace(text)
        lines = [ln.rstrip() for ln in text.splitlines()]

        sections = []
        current_heading = "Untitled Section"
        current_body = []

        for line in lines:
            stripped = line.strip()
            if not stripped:
                if current_body and current_body[-1] != "":
                    current_body.append("")
                continue

            if self.is_heading(stripped):
                if current_body:
                    sections.append({
                        "heading": current_heading,
                        "body": "\n".join(current_body).strip()
                    })
                    current_body = []
                current_heading = stripped
            else:
                current_body.append(stripped)

        if current_body:
            sections.append({
                "heading": current_heading,
                "body": "\n".join(current_body).strip()
            })

        # Merge tiny sections into previous one
        merged = []
        for sec in sections:
            body_len = len(sec["body"])
            if merged and body_len < SECTION_MERGE_GAP:
                merged[-1]["body"] += "\n\n" + sec["heading"] + "\n" + sec["body"]
            else:
                merged.append(sec)

        return merged

    # -------------------------
    # Sentence split
    # -------------------------
    def sent_split(self, text: str) -> List[str]:
        try:
            return [s.strip() for s in nltk.sent_tokenize(text) if s.strip()]
        except Exception:
            parts = re.split(r"(?<=[.!?])\s+", text)
            return [p.strip() for p in parts if p.strip()]

    # -------------------------
    # Semantic topic chunking
    # -------------------------
    def semantic_chunk_section(self, heading: str, body: str) -> List[str]:
        section_text = f"{heading}\n{body}".strip()

        if len(section_text) <= self.max_chars:
            return [section_text]

        paragraphs = [p.strip() for p in re.split(r"\n\s*\n", body) if p.strip()]
        if len(paragraphs) <= 1:
            return self.semantic_chunk_sentences(heading, body)

        chunks = []
        current = [heading]
        current_len = len(heading) + 1

        # paragraph-first grouping
        for para in paragraphs:
            if current_len + len(para) + 2 <= self.max_chars:
                current.append(para)
                current_len += len(para) + 2
            else:
                block = "\n\n".join(current).strip()
                if len(block) > self.token_guard_chars:
                    chunks.extend(self.semantic_chunk_sentences(heading, "\n\n".join(current[1:])))
                else:
                    chunks.append(block)

                current = [heading, para]
                current_len = len(heading) + len(para) + 2

        if len(current) > 1:
            block = "\n\n".join(current).strip()
            if len(block) > self.token_guard_chars:
                chunks.extend(self.semantic_chunk_sentences(heading, "\n\n".join(current[1:])))
            else:
                chunks.append(block)

        return chunks

    def semantic_chunk_sentences(self, heading: str, body: str) -> List[str]:
        sentences = self.sent_split(body)
        if not sentences:
            return [f"{heading}\n{body}".strip()]

        if self.embedding_model is None or len(sentences) < 3:
            return self.rule_based_sentence_chunking(heading, sentences)

        try:
            embeddings = self.embedding_model.encode(sentences, normalize_embeddings=True)
        except Exception as e:
            logger.warning(f"Embedding encode failed, fallback rule-based: {e}")
            return self.rule_based_sentence_chunking(heading, sentences)

        chunks = []
        current = [sentences[0]]

        for i in range(1, len(sentences)):
            prev_emb = embeddings[i - 1]
            curr_emb = embeddings[i]
            sim = float(np.dot(prev_emb, curr_emb))

            current_text = " ".join(current)
            next_sentence = sentences[i]

            should_split = False

            if sim < self.semantic_threshold and len(current_text) >= self.min_chars:
                should_split = True

            if len(current_text) + len(next_sentence) + len(heading) + 2 > self.max_chars:
                should_split = True

            if should_split:
                chunks.append(f"{heading}\n{' '.join(current)}".strip())
                current = [next_sentence]
            else:
                current.append(next_sentence)

        if current:
            chunks.append(f"{heading}\n{' '.join(current)}".strip())

        final_chunks = []
        for c in chunks:
            final_chunks.extend(self.apply_recursive_token_guard(c))

        return final_chunks

    def rule_based_sentence_chunking(self, heading: str, sentences: List[str]) -> List[str]:
        chunks = []
        current = []

        for sent in sentences:
            candidate = (" ".join(current) + " " + sent).strip()
            total_len = len(heading) + 1 + len(candidate)

            if total_len > self.max_chars and current:
                chunks.append(f"{heading}\n{' '.join(current)}".strip())
                current = [sent]
            else:
                current.append(sent)

        if current:
            chunks.append(f"{heading}\n{' '.join(current)}".strip())

        final_chunks = []
        for c in chunks:
            final_chunks.extend(self.apply_recursive_token_guard(c))

        return final_chunks

    # -------------------------
    # Recursive token guard
    # -------------------------
    def apply_recursive_token_guard(self, text: str) -> List[str]:
        text = normalize_whitespace(text)

        if len(text) <= self.token_guard_chars:
            return [text]

        # split by paragraph
        paras = [p.strip() for p in re.split(r"\n\s*\n", text) if p.strip()]
        if len(paras) > 1:
            out = []
            current = []

            for p in paras:
                candidate = "\n\n".join(current + [p]).strip()
                if len(candidate) > self.token_guard_chars and current:
                    out.extend(self.apply_recursive_token_guard("\n\n".join(current)))
                    current = [p]
                else:
                    current.append(p)

            if current:
                out.extend(self.apply_recursive_token_guard("\n\n".join(current)))
            return out

        # split by sentence
        sents = self.sent_split(text)
        if len(sents) > 1:
            out = []
            current = []

            for s in sents:
                candidate = (" ".join(current) + " " + s).strip()
                if len(candidate) > self.token_guard_chars and current:
                    out.append(" ".join(current).strip())
                    current = [s]
                else:
                    current.append(s)

            if current:
                out.append(" ".join(current).strip())

            return out

        # hard split fallback
        pieces = []
        start = 0
        step = self.token_guard_chars
        while start < len(text):
            pieces.append(text[start:start + step].strip())
            start += step
        return [p for p in pieces if p]

    # -------------------------
    # End-to-end
    # -------------------------
    def build_final_chunks(self, raw_text: str) -> List[str]:
        sections = self.split_into_sections(raw_text)
        final_chunks = []

        for sec in sections:
            heading = sec["heading"]
            body = sec["body"]

            if not body.strip():
                continue

            sub_chunks = self.semantic_chunk_section(heading, body)
            for c in sub_chunks:
                if not looks_like_noise(c):
                    final_chunks.append(c)

        return final_chunks


# ============================
# DOMAIN-INDEPENDENT TOPIC DISCOVERY
# ============================
class DynamicTopicDiscoverer:
    """
    Domain-independent topic discovery using embeddings + clustering.

    This intentionally does not hardcode BFSI, healthcare, legal, HR, or any
    other domain labels. Topics are discovered from the uploaded document itself.
    """

    def __init__(self, llm_model=None):
        self.llm_model = llm_model
        self.embedding_model = None

        if SentenceTransformer is not None:
            try:
                model_name = os.getenv(
                    "TOPIC_DISCOVERY_EMBED_MODEL",
                    os.getenv("SMART_CHUNK_EMBED_MODEL", "sentence-transformers/all-MiniLM-L6-v2"),
                )
                self.embedding_model = SentenceTransformer(model_name)
                logger.info(f"Loaded topic discovery embedding model: {model_name}")
            except Exception as e:
                logger.warning(f"Topic discovery embedding model unavailable: {e}")

    def _choose_cluster_count(self, n_chunks: int) -> int:
        """
        Choose a reasonable number of clusters based on chunk count.
        """
        if n_chunks <= 0:
            return 0
        if n_chunks <= 3:
            return 1
        if n_chunks <= 10:
            return min(n_chunks, 3)

        estimated = int(math.sqrt(n_chunks))
        return clamp(estimated, MIN_TOPIC_CLUSTERS, min(MAX_TOPIC_CLUSTERS, n_chunks))

    def _fallback_topic_name(self, text: str) -> str:
        """
        Domain-independent fallback topic name when LLM labeling is unavailable.
        Uses the first heading-like line or frequent meaningful words.
        """
        text = normalize_whitespace(text or "")
        if not text:
            return "General topic"

        first_line = text.split("\n")[0].strip()
        if 5 <= len(first_line) <= 90:
            return first_line[:90]

        words = re.findall(r"[A-Za-z][A-Za-z0-9\-]{2,}", text)
        stopwords = {
            "the", "and", "for", "with", "that", "this", "from", "are", "was", "were",
            "must", "should", "will", "can", "may", "not", "has", "have", "into",
            "their", "there", "which", "when", "where", "what", "how", "why", "who",
            "shall", "than", "then", "also", "such", "these", "those", "been", "being",
            "they", "them", "your", "our", "his", "her", "its", "per", "via",
        }

        freq: Dict[str, int] = {}
        for w in words:
            wl = w.lower()
            if wl in stopwords or len(wl) < 3:
                continue
            freq[wl] = freq.get(wl, 0) + 1

        if freq:
            top_words = [w for w, _ in sorted(freq.items(), key=lambda kv: (-kv[1], kv[0]))[:4]]
            return " / ".join(top_words)

        return "General topic"

    def _label_topic_with_llm(self, sample_text: str) -> str:
        """
        Labels a discovered cluster using the LLM.
        The label is generated from document content only, so it remains domain independent.
        """
        if self.llm_model is None:
            return self._fallback_topic_name(sample_text)

        prompt = f"""
You are labeling a topic cluster from a document.

Return ONLY a short topic name of 3 to 8 words.
Do not include quotes.
Do not include explanation.
Do not mention the words topic or cluster.

TEXT:
{sample_text[:2500]}
""".strip()

        try:
            resp = self.llm_model.invoke(prompt)
            label = resp_to_text(resp).strip()
            label = re.sub(r"^[\"'`]+|[\"'`]+$", "", label).strip()
            label = re.sub(r"\s+", " ", label)
            label = label[:90].strip()

            if 3 <= len(label) <= 90:
                return label

        except Exception as e:
            logger.warning(f"LLM topic labeling failed; fallback used: {e}")

        return self._fallback_topic_name(sample_text)

    def _assign_single_topic(self, chunks_df: pd.DataFrame, confidence: float = 0.5) -> pd.DataFrame:
        chunks_df = chunks_df.copy()
        combined = "\n\n".join(chunks_df["chunk"].astype(str).head(TOPIC_LABEL_SAMPLE_CHUNKS).tolist())
        chunks_df["topic_id"] = 0
        chunks_df["topic_name"] = self._label_topic_with_llm(combined)
        chunks_df["topic_confidence"] = confidence
        return chunks_df

    def assign_topics(self, chunks_df: pd.DataFrame) -> pd.DataFrame:
        """
        Adds dynamic topic metadata to chunks_df:
        - chunk_hash
        - topic_id
        - topic_name
        - topic_confidence
        """
        if chunks_df.empty:
            out = chunks_df.copy()
            for col in ["chunk_hash", "topic_id", "topic_name", "topic_confidence"]:
                if col not in out.columns:
                    out[col] = None
            return out

        chunks_df = chunks_df.copy()
        chunks_df["chunk"] = chunks_df["chunk"].astype(str)

        if "chunk_hash" not in chunks_df.columns:
            chunks_df["chunk_hash"] = chunks_df["chunk"].apply(compute_text_hash)

        chunks_df = chunks_df.drop_duplicates(subset=["chunk_hash"]).reset_index(drop=True)
        n_chunks = len(chunks_df)

        if n_chunks <= 1:
            return self._assign_single_topic(chunks_df, confidence=1.0)

        if self.embedding_model is None:
            logger.warning("Embedding model unavailable. Assigning one fallback dynamic topic.")
            return self._assign_single_topic(chunks_df, confidence=0.5)

        if MiniBatchKMeans is None or pairwise_distances_argmin_min is None:
            logger.warning("sklearn clustering unavailable. Assigning one fallback dynamic topic.")
            return self._assign_single_topic(chunks_df, confidence=0.5)

        texts = chunks_df["chunk"].astype(str).tolist()

        try:
            embeddings = self.embedding_model.encode(texts, normalize_embeddings=True)
        except Exception as e:
            logger.warning(f"Topic embedding encode failed. Assigning fallback topic: {e}")
            return self._assign_single_topic(chunks_df, confidence=0.5)

        k = self._choose_cluster_count(n_chunks)
        if k <= 1:
            return self._assign_single_topic(chunks_df, confidence=1.0)

        try:
            clusterer = MiniBatchKMeans(
                n_clusters=k,
                random_state=42,
                batch_size=min(256, max(16, n_chunks)),
                n_init=10,
            )
            labels = clusterer.fit_predict(embeddings)
        except Exception as e:
            logger.warning(f"Topic clustering failed. Assigning fallback topic: {e}")
            return self._assign_single_topic(chunks_df, confidence=0.5)

        closest_indices, _ = pairwise_distances_argmin_min(clusterer.cluster_centers_, embeddings)

        topic_names: Dict[int, str] = {}
        unique_labels = sorted(set(int(x) for x in labels))

        for topic_id in unique_labels:
            topic_indices = np.where(labels == topic_id)[0]
            if len(topic_indices) == 0:
                topic_names[topic_id] = f"Discovered area {topic_id + 1}"
                continue

            representative_texts = []
            center_idx = int(closest_indices[topic_id]) if topic_id < len(closest_indices) else int(topic_indices[0])
            representative_texts.append(str(chunks_df.iloc[center_idx]["chunk"]))

            for extra_idx in topic_indices[:TOPIC_LABEL_SAMPLE_CHUNKS]:
                representative_texts.append(str(chunks_df.iloc[int(extra_idx)]["chunk"]))

            sample_text = "\n\n".join(representative_texts)
            topic_names[topic_id] = self._label_topic_with_llm(sample_text)

        chunks_df["topic_id"] = labels
        chunks_df["topic_name"] = chunks_df["topic_id"].map(topic_names)

        try:
            centers = clusterer.cluster_centers_[labels]
            similarity = np.sum(embeddings * centers, axis=1)
            chunks_df["topic_confidence"] = np.clip(similarity, 0.0, 1.0)
        except Exception:
            chunks_df["topic_confidence"] = 0.5

        logger.info(f"✅ Dynamic topics discovered: {len(unique_labels)}")
        return chunks_df

    def filter_by_user_topic(self, chunks_df: pd.DataFrame, topic_filter_text: str) -> pd.DataFrame:
        """
        Domain-independent topic filtering using semantic similarity.
        """
        topic_filter_text = (topic_filter_text or "").strip()
        if not topic_filter_text or chunks_df.empty:
            return chunks_df

        if self.embedding_model is None:
            logger.warning("Topic filter fallback: embedding model unavailable. Using text contains fallback.")
            text_filter = topic_filter_text.lower()
            topic_name_series = chunks_df["topic_name"] if "topic_name" in chunks_df.columns else pd.Series([""] * len(chunks_df))
            filtered = chunks_df[
                chunks_df["chunk"].astype(str).str.lower().str.contains(re.escape(text_filter), na=False)
                | topic_name_series.astype(str).str.lower().str.contains(re.escape(text_filter), na=False)
            ].copy()
            return filtered if not filtered.empty else chunks_df.head(TOPIC_FILTER_TOP_K)

        chunks_df = chunks_df.copy()
        try:
            filter_emb = self.embedding_model.encode([topic_filter_text], normalize_embeddings=True)[0]
            chunk_embs = self.embedding_model.encode(chunks_df["chunk"].astype(str).tolist(), normalize_embeddings=True)
            sims = np.dot(chunk_embs, filter_emb)
            chunks_df["topic_filter_similarity"] = sims
        except Exception as e:
            logger.warning(f"Topic filter failed. Returning unfiltered chunks: {e}")
            return chunks_df

        filtered = chunks_df[chunks_df["topic_filter_similarity"] >= TOPIC_FILTER_SIM_THRESHOLD].copy()

        if filtered.empty:
            logger.warning(
                f"No chunks matched topic filter '{topic_filter_text}' at threshold={TOPIC_FILTER_SIM_THRESHOLD}. "
                "Using top semantic matches instead."
            )
            filtered = chunks_df.sort_values("topic_filter_similarity", ascending=False).head(TOPIC_FILTER_TOP_K)

        return filtered.drop(columns=["topic_filter_similarity"], errors="ignore")


# ============================
# PROMPT FACTORY
# ============================
# ============================
# PROMPT FACTORY
# ============================
class PromptFactory:
    @staticmethod
    def generation_prompt() -> PromptTemplate:
        prompt_text = """
You are an expert evaluator generating production-grade ground-truth Q/A pairs from the given PASSAGE.

CRITICAL OUTPUT RULES:
- Return ONLY a valid JSON object matching the schema below.
- Output MUST start with "{" and end with "}".
- Do not include Markdown, code fences, comments, or explanatory text.

JSON SCHEMA:
{
  "qas": [
    {
      "question": "A standalone question grounded in the passage",
      "answer": "A complete, self-contained ground-truth answer grounded only in the passage."
    }
  ]
}

GENERATION RULES:
- Generate EXACTLY {target_q} detailed Q/A pairs.
- Each question must test ONE distinct, verifiable fact, rule, event, number, condition, definition, risk, process, decision, or stated viewpoint from the passage.
- Questions must be standalone: include the relevant entity, product, policy, person, year, section, or context where needed.
- Do not ask vague/meta questions such as "What is the tone of the passage?", "What is the main subject of the passage?", or "Which of the following is not mentioned?"
- Do not generate duplicate or semantically similar questions.
- Use ONLY information explicitly stated in the PASSAGE.
- No external knowledge, assumptions, invented conditions, or inferred facts.
- Never copy facts, numbers, entities, values, or conditions from instructions or examples; only the PASSAGE is allowed as evidence.

ANSWER QUALITY RULES:
- Every answer must be a complete sentence, not a value-only answer.
- Every answer must be self-contained and understandable without reading the question.
- Every answer must repeat the main subject/entity from the question naturally.
- Never include filler phrases such as "according to the provided passage", "according to the passage", or "as stated in the provided passage".
- Never put the answer inside the question.
- Never create circular answers like "the investment offering was an investment offering".
- Every answer should normally contain at least 10 words.
- Preserve exact numbers, dates, currency symbols, percentages, ranges, names, and technical terms from the passage.
- If the passage contains conditions, limitations, exceptions, or comparisons, include them.
- If the passage states biased, unsafe, unlawful, discriminatory, or adversarial content, describe it as content in the document; do not endorse it as a recommendation.
- If a requested fact is not in the passage, do not create a Q/A pair for it.

PASSAGE:
{content}
""".strip()

        prompt_text = prompt_text.replace("{", "{{").replace("}", "}}")
        prompt_text = prompt_text.replace("{{content}}", "{content}")
        prompt_text = prompt_text.replace("{{target_q}}", "{target_q}")

        return PromptTemplate(input_variables=["content", "target_q"], template=prompt_text)


# ============================
# EXTRACTION (MULTI-FORMAT)
# ============================
def extract_text_pdf(path: str) -> List[Tuple[str, int]]:
    doc = fitz.open(path)
    output = []
    for i, page in enumerate(doc):
        output.append((page.get_text("text"), i + 1))
    doc.close()
    return output


def extract_text_docx(path: str) -> List[Tuple[str, int]]:
    d = docx.Document(path)
    full_text = "\n".join([para.text for para in d.paragraphs])
    return [(full_text, 1)]


def extract_text_odt(path: str) -> List[Tuple[str, int]]:
    text = pypandoc.convert_file(path, "plain")
    return [(text, 1)]


def extract_text_txt(path: str) -> List[Tuple[str, int]]:
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        return [(f.read(), 1)]


def extract_text_rtf(path: str) -> List[Tuple[str, int]]:
    text = pypandoc.convert_file(path, "plain")
    return [(text, 1)]


def extract_text_html(path: str) -> List[Tuple[str, int]]:
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        soup = BeautifulSoup(f.read(), "html.parser")
    text = soup.get_text(separator="\n")
    return [(text, 1)]


def extract_text_md(path: str) -> List[Tuple[str, int]]:
    text = pypandoc.convert_file(path, "plain")
    return [(text, 1)]


# ============================
# DOCUMENT CHUNKER
# ============================
class DocumentChunker:
    def __init__(
        self,
        dataset_folder: Optional[str] = None,
        single_document: Optional[str] = None,
    ):
        self.dataset_folder = dataset_folder
        self.single_document = single_document
        self.skip_noise_chunks = os.getenv("TESTSET_SKIP_NOISE", "true").lower() in {"1", "true", "yes"}
        self.smart_chunker = SmartChunker()

    def load_chunks_df(self) -> pd.DataFrame:
        supported_extractors = {
            ".pdf": extract_text_pdf,
            ".docx": extract_text_docx,
            ".odt": extract_text_odt,
            ".txt": extract_text_txt,
            ".rtf": extract_text_rtf,
            ".html": extract_text_html,
            ".htm": extract_text_html,
            ".md": extract_text_md,
        }

        files = (
            [self.single_document]
            if self.single_document
            else [f for f in os.listdir(self.dataset_folder) if os.path.isfile(os.path.join(self.dataset_folder, f))]
        )

        chunk_rows = []

        for file in files:
            ext = os.path.splitext(file)[1].lower()
            if ext not in supported_extractors:
                logger.warning(f"Skipping unsupported file: {file}")
                continue

            file_path = os.path.join(self.dataset_folder, file)
            extractor = supported_extractors[ext]

            logger.info(f"📄 Extracting: {file}")
            try:
                extracted_pages = extractor(file_path)
            except Exception as e:
                logger.error(f"Failed to extract {file}: {e}", exc_info=True)
                continue

            for text, page_num in extracted_pages:
                text = normalize_whitespace(text)
                if not text.strip():
                    continue

                final_chunks = self.smart_chunker.build_final_chunks(text)

                for chunk in final_chunks:
                    if self.skip_noise_chunks and looks_like_noise(chunk):
                        continue

                    chunk_rows.append(
                        {
                            "chunk": chunk,
                            "source": file,
                            "page_idx": coerce_page_idx(page_num),
                            "chunk_hash": compute_text_hash(chunk),
                        }
                    )

        if not chunk_rows:
            logger.warning("No supported documents found or no chunks produced.")
            return pd.DataFrame(columns=["chunk", "source", "page_idx", "chunk_hash"])

        df = pd.DataFrame(chunk_rows)
        logger.info(f"✅ Final smart chunks created: {len(df)}")
        return df


# ============================
# DATASET MANAGER
# ============================
class TestDatasetManager:
    def __init__(
        self,
        auditor: str,
        dataset_folder: Optional[str] = None,
        document_path: Optional[str] = None,
    ):
        if not dataset_folder and not document_path:
            raise ValueError("Either dataset_folder or document_path must be provided")

        self.auditor = auditor

        if document_path:
            if not os.path.isfile(document_path):
                raise FileNotFoundError(f"Document not found: {document_path}")
            self.dataset_folder = os.path.dirname(document_path)
            self._single_document = os.path.basename(document_path)
        else:
            self.dataset_folder = dataset_folder
            self._single_document = None

        self.output_dir = OUTPUT_DIR
        self.output_csv = os.getenv(
            "TESTSET_OUTPUT_FILE",
            os.path.join(self.output_dir, "dataset.csv"),
        )
        self.max_rows = min(self._env_int("TESTSET_MAX_ROWS", default=TESTSET_MAX_ROWS) or TESTSET_MAX_ROWS, 2000)
        self.target_rows = min(self._env_int("TESTSET_TARGET_ROWS", default=TESTSET_TARGET_ROWS) or TESTSET_TARGET_ROWS, self.max_rows, 2000)

        self.chunker = DocumentChunker(
            dataset_folder=self.dataset_folder,
            single_document=self._single_document,
        )

        self.audit_logger = AuditLogger(auditor=self.auditor, output_dir=self.output_dir)
        self.quality_scorer = DatasetQualityScorer()
        self.prompt = PromptFactory.generation_prompt()



        self.model = build_chat_model(
            provider=LLM_CONFIG["provider"],
            model=LLM_CONFIG["model"],
            temperature=LLM_CONFIG["temperature"],
            base_url=LLM_CONFIG["base_url"],
        )

        logger.info(
            f"Initialized TestDatasetManager | folder={self.dataset_folder} | document={self._single_document}"
        )

        self._structured_enabled = False
        try:
            self.model = self.model.bind(response_format={"type": "json_object"})
            self._structured_enabled = True
            logger.info("Enabled response_format=json_object via model.bind()")
        except Exception:
            logger.info("Model does not support response_format bind; using robust JSON extraction + retry.")

        self.topic_discoverer = DynamicTopicDiscoverer(llm_model=self.model)
        self.rejected_pairs: List[Dict[str, Any]] = []

    @staticmethod
    def _env_int(name: str, default: Optional[int] = None) -> Optional[int]:
        v = os.getenv(name, "").strip()
        if not v:
            return default
        return int(v) if v.isdigit() else default
    
    
    def _looks_like_excel_file(self, path: str) -> bool:
        with open(path, "rb") as f:
            start = f.read(8)

        # XLSX files start with PK, old XLS files often start with D0 CF
        return start.startswith(b"PK") or start.startswith(b"\xD0\xCF\x11\xE0")    

    
    # -----------------------------
    # Client dataset readers
    # -----------------------------
    def _load_client_csv(self, path: str) -> pd.DataFrame:
        """
        Robust CSV loader for uploaded client datasets.

        Handles:
        - UTF-8 CSV
        - UTF-8 BOM CSV
        - Excel/Windows encoded CSV files
        - Latin encoded CSV files
        - CSV files with minor bad bytes
        """

        if self._looks_like_excel_file(path):
            logger.warning(
                f"File has .csv extension but appears to be an Excel file: {path}. "
                "Reading with pd.read_excel()."
            )
            return pd.read_excel(path)

        encodings_to_try = [
            "utf-8",
            "utf-8-sig",
            "cp1252",
            "ISO-8859-1",
            "latin1",
        ]

        last_error = None

        for enc in encodings_to_try:
            try:
                logger.info(f"Trying to read client CSV with encoding={enc}")

                return pd.read_csv(
                    path,
                    encoding=enc,
                    encoding_errors="replace",
                    engine="python",
                    on_bad_lines="warn",
                )

            except Exception as e:
                last_error = e
                logger.warning(f"Failed reading CSV with encoding={enc}: {e}")

        raise ValueError(
            f"Unable to read client CSV file with supported encodings. "
            f"Last error: {last_error}"
        )
        
    
    def _load_client_excel(self, path: str) -> pd.DataFrame:
        sheet = os.getenv("CLIENT_EXCEL_SHEET", "").strip()
        if sheet:
            return pd.read_excel(path, sheet_name=sheet)
        return pd.read_excel(path)

    def _load_client_json(self, path: str) -> pd.DataFrame:
            """
            Robust JSON loader for client datasets.
            Supports:
            1. List of objects:
            [
                {"question": "...", "ground_truth": "..."},
                {"query": "...", "answer": "..."}
            ]
            2. List of strings:
            [
                "What is GST?",
                "What is the maximum loan amount?"
            ]
            3. Dict with data/items/qas/samples:
            {
                "data": [{"question": "...", "ground_truth": "..."}]
            }
            4. Dict with questions + answers:
            {
                "questions": ["..."],
                "ground_truth": ["..."]
            }
            5. Dict with queries only:
            {
                "queries": ["..."]
            }
            Query-only JSON is allowed. In that case ground_truth is kept empty.
            """

            with open(path, "r", encoding="utf-8", errors="replace") as f:
                obj = json.load(f)

            def _pick_question(item: dict) -> str:
                for key in ["question", "query", "input", "prompt", "user_query"]:
                    if key in item and item[key] is not None:
                        return str(item[key]).strip()
                return ""

            def _pick_answer(item: dict) -> str:
                for key in ["ground_truth", "answer", "answers", "expected_answer", "reference", "reference_answer"]:
                    if key in item and item[key] is not None:
                        value = item[key]

                        if isinstance(value, list):
                            return " ".join(str(x).strip() for x in value if str(x).strip())

                        return str(value).strip()

                return ""

            # --------------------------------------------------
            # Case 1: JSON is a list
            # --------------------------------------------------
            if isinstance(obj, list):
                if not obj:
                    return pd.DataFrame(columns=["question", "ground_truth"])

                # List of strings = query-only file
                if all(isinstance(x, str) for x in obj):
                    return pd.DataFrame({
                        "question": [str(x).strip() for x in obj if str(x).strip()],
                        "ground_truth": ["" for x in obj if str(x).strip()],
                    })

                # List of dicts
                if all(isinstance(x, dict) for x in obj):
                    rows = []

                    for item in obj:
                        q = _pick_question(item)
                        a = _pick_answer(item)

                        if q:
                            rows.append({
                                "question": q,
                                "ground_truth": a,
                            })

                    return pd.DataFrame(rows)

                raise ValueError("Unsupported JSON list format for client dataset")

            # --------------------------------------------------
            # Case 2: JSON is a dict
            # --------------------------------------------------
            if isinstance(obj, dict):

                # Common nested containers
                for container_key in ["data", "items", "qas", "samples", "examples", "records"]:
                    if isinstance(obj.get(container_key), list):
                        nested = obj[container_key]

                        if all(isinstance(x, str) for x in nested):
                            return pd.DataFrame({
                                "question": [str(x).strip() for x in nested if str(x).strip()],
                                "ground_truth": ["" for x in nested if str(x).strip()],
                            })

                        if all(isinstance(x, dict) for x in nested):
                            rows = []

                            for item in nested:
                                q = _pick_question(item)
                                a = _pick_answer(item)

                                if q:
                                    rows.append({
                                        "question": q,
                                        "ground_truth": a,
                                    })

                            return pd.DataFrame(rows)

                # questions + ground_truth / answers arrays
                if isinstance(obj.get("questions"), list):
                    questions = [str(x).strip() for x in obj["questions"] if str(x).strip()]

                    gt = obj.get("ground_truth")
                    if gt is None:
                        gt = obj.get("answers")
                    if gt is None:
                        gt = obj.get("expected_answers")
                    if gt is None:
                        gt = obj.get("references")

                    if isinstance(gt, list):
                        answers = [
                            "" if x is None else str(x).strip()
                            for x in gt
                        ]

                        n = min(len(questions), len(answers))
                        return pd.DataFrame({
                            "question": questions[:n],
                            "ground_truth": answers[:n],
                        })

                    # questions only
                    return pd.DataFrame({
                        "question": questions,
                        "ground_truth": ["" for _ in questions],
                    })

                # queries only
                if isinstance(obj.get("queries"), list):
                    queries = [str(x).strip() for x in obj["queries"] if str(x).strip()]
                    return pd.DataFrame({
                        "question": queries,
                        "ground_truth": ["" for _ in queries],
                    })

                # Single object
                q = _pick_question(obj)
                a = _pick_answer(obj)

                if q:
                    return pd.DataFrame([{
                        "question": q,
                        "ground_truth": a,
                    }])

            raise ValueError(
                "Unsupported JSON format for client dataset. "
                "Supported formats: list of dicts, list of strings, "
                "{questions:[...]}, {queries:[...]}, {data:[...]}, {qas:[...]}"
            )
        
    def load_client_dataset(self, path: str) -> pd.DataFrame:
        logger.info(f"📥 Client dataset detected. Loading: {path}")

        ext = os.path.splitext(path)[1].lower()

        if ext == ".csv":
            df = self._load_client_csv(path)
        elif ext in {".xlsx", ".xls"}:
            df = self._load_client_excel(path)
        elif ext == ".json":
            df = self._load_client_json(path)
        else:
            raise ValueError("❌ Unsupported client dataset type. Use .csv, .json, .xlsx/.xls")

        if df is None or df.empty:
            raise ValueError("❌ Client dataset is empty.")

        df = df.copy()
        df.columns = [str(c).strip() for c in df.columns]

        # -----------------------------
        # Normalize question column
        # -----------------------------
        if "question" not in df.columns:
            question_aliases = [
                "questions",
                "query",
                "queries",
                "input",
                "prompt",
                "user_query",
                "user_question",
            ]

            for alias in question_aliases:
                if alias in df.columns:
                    df["question"] = df[alias]
                    break

        # -----------------------------
        # Normalize ground_truth column
        # -----------------------------
        if "ground_truth" not in df.columns:
            gt_aliases = [
                "answer",
                "answers",
                "expected_answer",
                "expected_answers",
                "reference",
                "reference_answer",
                "groundtruth",
                "ground_truths",
                "gt",
            ]

            for alias in gt_aliases:
                if alias in df.columns:
                    df["ground_truth"] = df[alias]
                    break

        allow_query_only = os.getenv(
            "ALLOW_QUERY_ONLY_CLIENT_DATASET",
            "false"
        ).lower() in {"1", "true", "yes"}

        if "question" not in df.columns:
            raise ValueError(
                "❌ Client dataset schema invalid: missing 'question'. "
                "Accepted aliases: question, questions, query, queries, input, prompt, user_query."
            )

        if "ground_truth" not in df.columns:
            if allow_query_only:
                logger.warning(
                    "⚠️ Client dataset has questions only and no ground_truth. "
                    "ALLOW_QUERY_ONLY_CLIENT_DATASET=true, so ground_truth will be empty."
                )
                df["ground_truth"] = ""
            else:
                raise ValueError(
                    "❌ Client dataset schema invalid: missing 'ground_truth'. "
                    "For overall evaluation, each question must have a ground_truth. "
                    "Accepted aliases: ground_truth, answer, answers, expected_answer, "
                    "reference, reference_answer, groundtruth, gt. "
                    "Set ALLOW_QUERY_ONLY_CLIENT_DATASET=true only for query-only testing."
                )

        # -----------------------------
        # Build output with metadata BEFORE filtering
        # -----------------------------
        out = pd.DataFrame()

        out["question"] = (
            df["question"]
            .fillna("")
            .astype(str)
            .str.replace("\x00", " ", regex=False)
            .str.strip()
        )

        out["ground_truth"] = (
            df["ground_truth"]
            .fillna("")
            .astype(str)
            .str.replace("\x00", " ", regex=False)
            .str.strip()
        )

        out.loc[out["question"].str.lower().isin({"nan", "none", "null"}), "question"] = ""
        out.loc[out["ground_truth"].str.lower().isin({"nan", "none", "null"}), "ground_truth"] = ""

        if "source" in df.columns:
            out["source"] = (
                df["source"]
                .fillna("client_dataset")
                .astype(str)
                .str.strip()
            )
            out.loc[out["source"] == "", "source"] = "client_dataset"
        else:
            out["source"] = "client_dataset"

        if "page_idx" in df.columns:
            out["page_idx"] = df["page_idx"].apply(coerce_page_idx)
        else:
            out["page_idx"] = None

        if "source_hash" in df.columns:
            out["source_hash"] = df["source_hash"].fillna("").astype(str).str.strip()
            out.loc[out["source_hash"] == "", "source_hash"] = None
        else:
            out["source_hash"] = None

        # -----------------------------
        # Validate rows
        # -----------------------------
        if allow_query_only:
            before = len(out)
            out = out[out["question"] != ""].reset_index(drop=True)
            dropped = before - len(out)

            if dropped:
                logger.warning(f"⚠️ Dropped {dropped} client rows with empty question.")
        else:
            missing_q_count = int((out["question"] == "").sum())
            missing_gt_count = int((out["ground_truth"] == "").sum())

            if missing_q_count > 0 or missing_gt_count > 0:
                raise ValueError(
                    f"❌ Client dataset has invalid rows. "
                    f"missing_question_rows={missing_q_count}, "
                    f"missing_ground_truth_rows={missing_gt_count}. "
                    "For overall evaluation, every row must contain both question and ground_truth."
                )

            out = out[
                (out["question"] != "") &
                (out["ground_truth"] != "")
            ].reset_index(drop=True)

        if out.empty:
            raise ValueError(
                "❌ Client dataset has no valid rows after cleaning. "
                "Please upload a dataset with valid question and ground_truth pairs."
            )

        logger.info(
            f"🔒 Generation DISABLED (client dataset takes priority). "
            f"rows={len(out)} | allow_query_only={allow_query_only}"
        )

        self.audit_logger.log(source_type="CLIENT")
        return ensure_dataset_schema(out)
    # -----------------------------
    # LLM invoke + parse helpers
    # -----------------------------
    def _invoke_raw(self, prompt: str) -> str:
        try:
            resp = self.model.invoke(prompt, max_tokens=1200)
            return resp_to_text(resp)

        except LengthFinishReasonError:
            logger.warning("⚠️ LLM response exceeded token limit. Retrying with smaller prompt.")
            try:
                if isinstance(prompt, str) and len(prompt) > 3200:
                    prompt = prompt[:3200]
                resp = self.model.invoke(prompt, max_tokens=900)
                return resp_to_text(resp)
            except Exception as retry_error:
                logger.error(f"Retry after token overflow failed: {retry_error}")
                return ""

        except Exception as e:
            logger.error(f"Model invocation failed: {e}", exc_info=True)
            return ""

    def _parse_or_retry(self, prompt_text: str, passage_text: str, chunk_idx: int, target_q: int) -> Optional[dict]:
        raw1 = self._invoke_raw(prompt_text)
        try:
            return extract_first_json_object(raw1)
        except Exception:
            repair = f"""
Return ONLY a valid JSON object with EXACTLY this schema:
{{"qas":[{{"question":"...","answer":"..."}}]}}

Rules:
- Output must start with "{{" and end with "}}"
- No extra keys, no markdown, no commentary
- Generate EXACTLY {target_q} Q/A pairs
- Each question must broadly cover the key aspects of the passage
- Answers must be grounded only in the passage

PASSAGE:
{passage_text}
""".strip()

            raw2 = self._invoke_raw(repair)
            try:
                return extract_first_json_object(raw2)
            except Exception as e2:
                logger.warning(f"❌ Invalid JSON — chunk skipped ({chunk_idx}): {e2}")
                logger.debug(f"Raw try1 first 1200 chars:\n{raw1[:1200]}")
                logger.debug(f"Raw try2 first 1200 chars:\n{raw2[:1200]}")
                return None

    @staticmethod
    def _normalize_dynamic_qas(data: dict, max_q: int) -> List[Tuple[str, str]]:
        pairs: List[Tuple[str, str]] = []

        if isinstance(data, dict) and isinstance(data.get("qas"), list):
            for item in data["qas"]:
                if not isinstance(item, dict):
                    continue
                q = str(item.get("question", "")).strip()
                a = item.get("answer", None)
                a = "I don't know" if a is None or str(a).strip() == "" else str(a).strip()
                if q:
                    pairs.append((q, a))

        if not pairs and isinstance(data, dict) and isinstance(data.get("questions"), list) and isinstance(data.get("answers"), list):
            qs = [str(x).strip() for x in data["questions"] if str(x).strip()]
            ans = [("I don't know" if x is None or str(x).strip() == "" else str(x).strip()) for x in data["answers"]]
            n = min(len(qs), len(ans))
            for i in range(n):
                pairs.append((qs[i], ans[i]))

        return pairs[:max_q]

    def _local_pair_issues(self, question: str, answer: str, passage: str) -> List[str]:
        """
        Local deterministic quality gates.

        These gates catch the exact production failures observed:
        - value-only answers such as "£0.27 million"
        - vague questions such as "What was the FY2023 profit?"
        - prompt/example leakage such as numeric values not present in the passage
        - incomplete or very short answers
        """
        issues: List[str] = []
        q = str(question or "").strip()
        a = str(answer or "").strip()
        passage = str(passage or "")

        a = sanitize_ground_truth_text(a)

        if not q:
            issues.append("empty_question")
        if not a:
            issues.append("empty_answer")

        if q and (is_question_too_vague(q) or is_bad_question_form(q)):
            issues.append("vague_or_bad_question_form")

        if q and a and REJECT_TEMPLATE_GROUND_TRUTH and has_template_ground_truth(answer):
            issues.append("template_ground_truth_phrase")

        if q and a and REJECT_ANSWER_LEAK_IN_QUESTION and answer_appears_inside_question(q, a):
            issues.append("answer_leaked_in_question")

        if q and a and REJECT_CIRCULAR_ANSWERS and is_circular_or_uninformative_answer(q, a):
            issues.append("circular_or_uninformative_answer")

        if a and is_value_only_answer(a):
            issues.append("value_only_answer")

        if a and has_speculative_or_meta_answer(a):
            issues.append("speculative_meta_or_fragment_answer")

        if a and not has_complete_sentence_shape(a):
            issues.append("incomplete_or_short_answer")

        if REJECT_UNSUPPORTED_NUMERIC_VALUES and a:
            unsupported = unsupported_values_in_answer(a, passage)
            if unsupported:
                issues.append("unsupported_values:" + ", ".join(unsupported[:5]))

        # Reject obvious fallback/not-found answers during generation.
        # Not-found rows should be created intentionally as boundary tests, not by passage-grounded generation.
        if a.lower().strip().rstrip(".") in {"i don't know", "not found", "not found in provided documents"}:
            issues.append("not_found_generated_from_passage")

        return issues

    def _heuristic_repair_pair(self, question: str, answer: str) -> Tuple[str, str]:
        """
        Deterministic repair for value-only answers.
        It wraps the original value into a natural sentence without using template filler.
        """
        q = str(question or "").strip()
        a = sanitize_ground_truth_text(str(answer or "").strip().strip('"').strip("'"))
        a_value = a.rstrip(".").strip()
        q_clean = q.rstrip("?").strip()
        q_lower = q_clean.lower()

        repaired_answer = ""

        # When did WANdisco expect to recommence trading? -> WANdisco expected to recommence trading on 25 July 2023.
        m = re.match(r"^when\s+did\s+(.+?)\s+(expect\s+to\s+.+)$", q_clean, flags=re.I)
        if m:
            subject = m.group(1).strip()
            action = m.group(2).strip()
            action = re.sub(r"^expect\s+to", "expected to", action, flags=re.I)
            repaired_answer = f"{subject} {action} on {a_value}."

        # When was X? -> X was on date.
        if not repaired_answer:
            m = re.match(r"^when\s+was\s+(.+)$", q_clean, flags=re.I)
            if m:
                subject = m.group(1).strip()
                repaired_answer = f"{subject} was on {a_value}."

        # What was/is/were/are X? -> The X was/is Y.
        if not repaired_answer:
            m = re.match(r"^what\s+(was|is|were|are)\s+(.+)$", q_clean, flags=re.I)
            if m:
                verb = m.group(1).lower()
                subject = m.group(2).strip()
                if not subject.lower().startswith(("the ", "hardy", "wandisco", "cameron", "pullam", "hmrc")):
                    subject = "the " + subject
                repaired_answer = f"{subject[0].upper() + subject[1:]} {verb} {a_value}."

        # How much/many -> The amount/number ... was Y.
        if not repaired_answer:
            m = re.match(r"^how\s+(much|many)\s+(.+)$", q_clean, flags=re.I)
            if m:
                noun = "amount" if m.group(1).lower() == "much" else "number"
                rest = m.group(2).strip()
                repaired_answer = f"The {noun} {rest} was {a_value}."

        # Who served/Who was -> Named answer.
        if not repaired_answer:
            m = re.match(r"^who\s+(.+)$", q_clean, flags=re.I)
            if m:
                rest = m.group(1).strip()
                repaired_answer = f"{a_value} {rest}."

        # Do not create generic wrappers such as "The answer to ... is ...".
        # If no safe deterministic pattern is available, let validation reject the pair
        # or let the LLM repair layer handle it.
        if not repaired_answer:
            return q, ""

        repaired_answer = sanitize_ground_truth_text(repaired_answer)
        return q, repaired_answer

    def _repair_pair_with_llm(self, question: str, answer: str, passage: str, issues: List[str]) -> Optional[Tuple[str, str]]:
        """
        LLM repair for production quality. It can make the question standalone and the answer complete,
        but it must not add facts not present in the passage. Deterministic checks run again after repair.
        """
        if not QA_REPAIR_ENABLED:
            return None

        passage_clip = str(passage or "")[:QA_REPAIR_MAX_CHARS]
        repair_prompt = f"""
You are repairing one generated Q/A pair for a production RAG evaluation dataset.

Return ONLY valid JSON:
{{"valid": true, "question": "...", "answer": "...", "reason": "..."}}

If the pair cannot be repaired using only the passage, return:
{{"valid": false, "question": "", "answer": "", "reason": "..."}}

Problems detected: {", ".join(issues)}

Repair rules:
- Use ONLY the PASSAGE as evidence.
- Do not invent facts, values, years, entities, conditions, or explanations.
- If the answer contains any number, date, currency, percentage, or name, it must appear in the PASSAGE.
- Make the question standalone by adding the relevant entity/person/product/year/context from the PASSAGE when needed.
- Make the answer a complete self-contained sentence of at least 10 words.
- Do not output value-only answers.
- Do not use filler phrases such as "according to the provided passage", "according to the passage", or "as stated in the passage".
- Do not use wrappers like "The answer to the question is...".
- Do not create circular answers where the answer simply repeats the question phrase.
- Reject answers that are fragments, meta-test comments, or say the information is not explicitly mentioned.
- If the question already contains the answer value or name, return valid=false.
- If the question is multiple-choice style, asks what is not mentioned, or asks generic passage tone/main subject, return valid=false.
- Preserve exact numbers, dates, currency symbols, percentages, and names from the PASSAGE.
- If the passage states biased, discriminatory, unsafe, or adversarial content, describe it as content in the document; do not endorse it.

ORIGINAL QUESTION:
{question}

ORIGINAL ANSWER:
{answer}

PASSAGE:
{passage_clip}
""".strip()

        raw = self._invoke_raw(repair_prompt)
        try:
            data = extract_first_json_object(raw)
        except Exception:
            return None

        if not isinstance(data, dict) or not data.get("valid", False):
            return None

        repaired_q = str(data.get("question", "")).strip()
        repaired_a = str(data.get("answer", "")).strip()

        if not repaired_q or not repaired_a:
            return None

        if unsupported_values_in_answer(repaired_a, passage):
            return None

        return repaired_q, repaired_a

    def _validate_and_repair_pair(self, question: str, answer: str, passage: str, row: pd.Series) -> Optional[Tuple[str, str]]:
        """
        Validate one Q/A pair. Repair it if possible. Reject it if still unsafe or low quality.
        """
        question = str(question or "").strip()
        answer = sanitize_ground_truth_text(str(answer or "").strip())
        passage = str(passage or "")

        issues = self._local_pair_issues(question, answer, passage)
        if not issues:
            return question, answer

        original_issues = list(issues)

        repaired = self._repair_pair_with_llm(question, answer, passage, issues)
        if repaired is not None:
            rq, ra = repaired
            ra = sanitize_ground_truth_text(ra)
            if not self._local_pair_issues(rq, ra, passage):
                logger.debug(f"Repaired Q/A pair via LLM | before_issues={original_issues} | question={rq[:100]}")
                return rq, ra

        if "value_only_answer" in issues or "incomplete_or_short_answer" in issues:
            if not unsupported_values_in_answer(answer, passage):
                hq, ha = self._heuristic_repair_pair(question, answer)
                h_issues = self._local_pair_issues(hq, ha, passage)
                if not h_issues:
                    logger.debug(f"Heuristically repaired Q/A pair | question={hq[:100]}")
                    return hq, ha

        self.rejected_pairs.append(
            {
                "question": question,
                "answer": answer,
                "source": row.get("source") if hasattr(row, "get") else None,
                "page_idx": row.get("page_idx") if hasattr(row, "get") else None,
                "issues": original_issues,
            }
        )
        return None

    def _row_quality_score(self, row: Dict[str, Any]) -> float:
        """Higher score wins when duplicates conflict."""
        q = str(row.get("question", ""))
        a = str(row.get("ground_truth", ""))
        score = 0.0
        score += min(answer_word_count(a), 40) / 40.0
        score += 0.5 if not is_value_only_answer(a) else -1.0
        score += 0.5 if has_complete_sentence_shape(a) else -0.5
        score += 0.3 if not is_question_too_vague(q) else -0.7
        if row.get("page_idx") not in {None, ""}:
            score += 0.2
        return score

    def estimate_coverage_questions(self, passage: str) -> int:
        """
        Generate only 1 or 2 questions.
        1 = focused chunk
        2 = dense/multi-aspect chunk
        """
        text = passage or ""
        words = len(text.split())
        bullets = len(re.findall(r"(^|\n)\s*[-•*]\s+", text))
        numbered = len(re.findall(r"\b\d+(\.\d+)?\b", text))
        headings = len(re.findall(r"\n[A-Z][^\n]{0,80}\n", text))
        colons = len(re.findall(r":", text))
        sentences = len(re.split(r"[.!?]+", text))

        density_score = 0
        if words > 220:
            density_score += 1
        if bullets >= 3:
            density_score += 1
        if numbered >= 6:
            density_score += 1
        if colons >= 4:
            density_score += 1
        if sentences >= 8:
            density_score += 1
        if headings >= 1:
            density_score += 1

        return 2 if density_score >= 3 else 1

    def _deduplicate_generated_rows(self, rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Production-grade deduplication.

        Removes:
        - exact duplicate questions
        - fuzzy duplicates such as "purpose" vs "objective"
        - semantic duplicates such as "maximum loan repayment period" vs "maximum repayment tenure"

        Keeps the row with stronger answer quality and traceability.
        """
        if not rows:
            return []

        cleaned: List[Dict[str, Any]] = []
        for row in rows:
            q = str(row.get("question", "")).strip()
            a = sanitize_ground_truth_text(str(row.get("ground_truth", "")).strip())
            passage = str(row.get("_passage", ""))
            source = str(row.get("source", ""))
            page_idx = coerce_page_idx(row.get("page_idx"))

            if not q or not a:
                continue

            final_issues = self._local_pair_issues(q, a, passage)
            if is_page_idx_required_for_source(source) and page_idx is None:
                final_issues.append("missing_page_idx_for_pdf")

            if final_issues:
                self.rejected_pairs.append(
                    {
                        "question": q,
                        "answer": a,
                        "source": source,
                        "page_idx": page_idx,
                        "issues": final_issues,
                    }
                )
                continue

            row = dict(row)
            row["ground_truth"] = a
            row["page_idx"] = page_idx
            cleaned.append(row)

        fuzzy_kept: List[Dict[str, Any]] = []
        buckets: Dict[str, List[int]] = {}

        for row in cleaned:
            source = str(row.get("source", "")).strip()
            q_norm = normalize_question_for_dedup(str(row.get("question", "")))
            if not q_norm:
                continue

            duplicate_idx: Optional[int] = None
            for idx in buckets.setdefault(source, []):
                existing_q_norm = normalize_question_for_dedup(str(fuzzy_kept[idx].get("question", "")))
                if q_norm == existing_q_norm:
                    duplicate_idx = idx
                    break
                ratio = SequenceMatcher(None, q_norm, existing_q_norm).ratio()
                if ratio >= FUZZY_QUESTION_DEDUP_THRESHOLD:
                    duplicate_idx = idx
                    break

            if duplicate_idx is None:
                buckets[source].append(len(fuzzy_kept))
                fuzzy_kept.append(row)
            else:
                if self._row_quality_score(row) > self._row_quality_score(fuzzy_kept[duplicate_idx]):
                    fuzzy_kept[duplicate_idx] = row

        if not SEMANTIC_QUESTION_DEDUP_ENABLED:
            deduped_rows = fuzzy_kept[: self.max_rows]
            logger.info(f"🧹 Deduplicated generated Q/A rows: before={len(rows)}, after={len(deduped_rows)}")
            return deduped_rows

        embed_model = getattr(getattr(self, "topic_discoverer", None), "embedding_model", None)
        if embed_model is None or len(fuzzy_kept) <= 1:
            deduped_rows = fuzzy_kept[: self.max_rows]
            logger.info(f"🧹 Deduplicated generated Q/A rows: before={len(rows)}, after={len(deduped_rows)}")
            return deduped_rows

        final_rows: List[Dict[str, Any]] = []
        final_embs_by_source: Dict[str, List[np.ndarray]] = {}
        final_indices_by_source: Dict[str, List[int]] = {}

        try:
            q_texts = [normalize_question_for_dedup(str(r.get("question", ""))) for r in fuzzy_kept]
            q_embs = embed_model.encode(q_texts, normalize_embeddings=True)
        except Exception as e:
            logger.warning(f"Semantic question dedup skipped because embedding failed: {e}")
            deduped_rows = fuzzy_kept[: self.max_rows]
            logger.info(f"🧹 Deduplicated generated Q/A rows: before={len(rows)}, after={len(deduped_rows)}")
            return deduped_rows

        for row, emb in zip(fuzzy_kept, q_embs):
            source = str(row.get("source", "")).strip()
            source_embs = final_embs_by_source.setdefault(source, [])
            source_indices = final_indices_by_source.setdefault(source, [])

            duplicate_final_idx: Optional[int] = None
            if source_embs:
                sims = np.dot(np.vstack(source_embs), emb)
                best_local = int(np.argmax(sims))
                if float(sims[best_local]) >= SEMANTIC_QUESTION_DEDUP_THRESHOLD:
                    duplicate_final_idx = source_indices[best_local]

            if duplicate_final_idx is None:
                source_indices.append(len(final_rows))
                source_embs.append(np.asarray(emb))
                final_rows.append(row)
            else:
                if self._row_quality_score(row) > self._row_quality_score(final_rows[duplicate_final_idx]):
                    final_rows[duplicate_final_idx] = row

            if len(final_rows) >= self.max_rows:
                break

        removed = len(rows) - len(final_rows)
        logger.info(
            f"🧹 Deduplicated generated Q/A rows: before={len(rows)}, "
            f"after={len(final_rows)}, removed={removed}"
        )
        return final_rows[: self.max_rows]

    def _select_dynamic_topic_balanced_chunks(self, chunks_df: pd.DataFrame, target_rows: int) -> pd.DataFrame:
        """
        Select chunks evenly across discovered topics.

        This prevents large documents from generating too many questions from one
        area while missing other meaningful areas. It is domain-independent because
        it relies on discovered topic_id/topic_name, not predefined categories.
        """
        if chunks_df.empty:
            return chunks_df

        chunks_df = chunks_df.copy()

        if "topic_id" not in chunks_df.columns:
            chunks_df["topic_id"] = 0
        if "topic_confidence" not in chunks_df.columns:
            chunks_df["topic_confidence"] = 0.5
        if "chunk_hash" not in chunks_df.columns:
            chunks_df["chunk_hash"] = chunks_df["chunk"].astype(str).apply(compute_text_hash)

        chunks_df = chunks_df.drop_duplicates(subset=["chunk_hash"]).reset_index(drop=True)

        estimated_q_per_chunk = max(1, MAX_QA_PER_CHUNK)
        target_chunks = max(1, int(math.ceil(target_rows / estimated_q_per_chunk)))
        target_chunks = min(target_chunks, len(chunks_df))

        topic_ids = chunks_df["topic_id"].dropna().unique().tolist()
        if not topic_ids:
            return chunks_df.head(target_chunks)

        per_topic = max(1, int(math.ceil(target_chunks / len(topic_ids))))
        selected_parts = []

        for topic_id in topic_ids:
            topic_df = chunks_df[chunks_df["topic_id"] == topic_id].copy()
            if topic_df.empty:
                continue

            topic_df["chunk_len"] = topic_df["chunk"].astype(str).str.len()
            topic_df = topic_df.sort_values(
                ["topic_confidence", "chunk_len"],
                ascending=[False, False],
            )
            selected_parts.append(topic_df.head(per_topic))

        if selected_parts:
            selected = pd.concat(selected_parts, ignore_index=True)
        else:
            selected = pd.DataFrame(columns=chunks_df.columns)

        selected = selected.drop_duplicates(subset=["chunk_hash"]).reset_index(drop=True)

        if len(selected) < target_chunks:
            selected_hashes = set(selected["chunk_hash"].astype(str).tolist()) if not selected.empty else set()
            remaining = chunks_df[~chunks_df["chunk_hash"].astype(str).isin(selected_hashes)].copy()
            remaining["chunk_len"] = remaining["chunk"].astype(str).str.len()
            remaining = remaining.sort_values(
                ["topic_confidence", "chunk_len"],
                ascending=[False, False],
            )
            selected = pd.concat([selected, remaining.head(target_chunks - len(selected))], ignore_index=True)

        selected = selected.head(target_chunks).drop(columns=["chunk_len"], errors="ignore")
        logger.info(
            f"🎯 Topic-balanced chunk selection: available={len(chunks_df)}, selected={len(selected)}, "
            f"target_rows={target_rows}, discovered_topics={len(topic_ids)}"
        )
        return selected

    def _build_coverage_plan(self, chunks_df: pd.DataFrame, target_rows: int) -> pd.DataFrame:
        """
        Coverage-driven chunk selection and per-chunk Q/A quota assignment.

        This is the production fix for the issue where a 4-page financial document
        generated only 2 Q/A pairs. Instead of sampling only a few chunks, this method:
        - keeps every discovered meaning-wise topic represented,
        - gives each topic a minimum Q/A budget,
        - assigns target_q to chunks,
        - still respects the absolute 2000-row cap.

        It is domain-independent because it relies on topic_id/topic_name discovered
        from embeddings/headings, not hardcoded topics like finance, legal, healthcare, etc.
        """
        if chunks_df.empty:
            return chunks_df

        df = chunks_df.copy()

        if "chunk" not in df.columns:
            return df

        if "chunk_hash" not in df.columns:
            df["chunk_hash"] = df["chunk"].astype(str).apply(compute_text_hash)

        if "topic_id" not in df.columns:
            df["topic_id"] = 0

        if "topic_name" not in df.columns:
            # Use the first line/heading as fallback topic name. Still domain-independent.
            df["topic_name"] = df["chunk"].astype(str).apply(
                lambda x: (normalize_whitespace(x).split("\n")[0][:90] or "General topic")
            )

        if "topic_confidence" not in df.columns:
            df["topic_confidence"] = 0.5

        df = df.drop_duplicates(subset=["chunk_hash"]).reset_index(drop=True)
        df["chunk_len"] = df["chunk"].astype(str).str.len()

        # For small docs, keep all meaningful chunks. This prevents missing sections.
        if len(df) <= COVERAGE_SMALL_DOC_CHUNK_LIMIT:
            selected = df.copy()
        else:
            # For large docs, select chunks evenly across topics.
            generation_target_rows = min(
                self.max_rows,
                max(target_rows, int(math.ceil(target_rows * COVERAGE_OVERSAMPLE_FACTOR))),
                2000,
            )
            target_chunks = max(1, int(math.ceil(generation_target_rows / max(1, MAX_DYNAMIC_QA_PER_CHUNK))))
            target_chunks = min(target_chunks, len(df))

            topic_keys = df["topic_id"].fillna(0).unique().tolist()
            per_topic_min = max(1, MIN_CHUNKS_PER_TOPIC)
            selected_parts = []

            # First pass: guarantee minimum topic representation.
            for topic_key in topic_keys:
                topic_df = df[df["topic_id"].fillna(0) == topic_key].copy()
                topic_df = topic_df.sort_values(["topic_confidence", "chunk_len"], ascending=[False, False])
                selected_parts.append(topic_df.head(per_topic_min))

            selected = pd.concat(selected_parts, ignore_index=True) if selected_parts else df.head(0)
            selected = selected.drop_duplicates(subset=["chunk_hash"]).reset_index(drop=True)

            # Second pass: fill remaining selected chunks without letting one topic dominate.
            if len(selected) < target_chunks:
                selected_hashes = set(selected["chunk_hash"].astype(str).tolist())
                remaining = df[~df["chunk_hash"].astype(str).isin(selected_hashes)].copy()
                extra_parts = []
                for topic_key in topic_keys:
                    topic_df = remaining[remaining["topic_id"].fillna(0) == topic_key].copy()
                    topic_df = topic_df.sort_values(["topic_confidence", "chunk_len"], ascending=[False, False])
                    extra_parts.append(topic_df.head(MAX_CHUNKS_PER_TOPIC))

                if extra_parts:
                    extra = pd.concat(extra_parts, ignore_index=True)
                    extra = extra.drop_duplicates(subset=["chunk_hash"]).reset_index(drop=True)
                    selected = pd.concat([selected, extra.head(target_chunks - len(selected))], ignore_index=True)

            selected = selected.head(target_chunks).reset_index(drop=True)

        # Assign Q/A quota per topic and chunk.
        selected["topic_name"] = selected["topic_name"].fillna("General topic")
        topic_count = max(1, selected["topic_name"].nunique())
        generation_target_rows = min(
            self.max_rows,
            max(target_rows, int(math.ceil(target_rows * COVERAGE_OVERSAMPLE_FACTOR))),
            2000,
        )

        # Base topic target. For short documents this ensures each topic gets enough questions.
        topic_budget = clamp(
            int(math.ceil(generation_target_rows / topic_count)),
            MIN_QA_PER_TOPIC,
            MAX_QA_PER_TOPIC,
        )

        target_q_values = []
        for _, r in selected.iterrows():
            topic_name = r.get("topic_name", "General topic")
            topic_chunk_count = int((selected["topic_name"] == topic_name).sum())
            per_chunk_q = int(math.ceil(topic_budget / max(1, topic_chunk_count)))

            # Dense chunks deserve more questions, but never exceed the dynamic cap.
            chunk_text = str(r.get("chunk", ""))
            bullets = len(re.findall(r"(^|\n)\s*[-•*]\s+", chunk_text))
            numbers = len(re.findall(r"(?:₹|£|\$|€)?\d+(?:[.,]\d+)*(?:%|p|m| million| lakhs| months| per annum)?", chunk_text, flags=re.I))
            if bullets >= 4 or numbers >= 4:
                per_chunk_q += 2
            elif bullets >= 2 or numbers >= 2:
                per_chunk_q += 1

            target_q_values.append(clamp(per_chunk_q, MIN_QA_PER_CHUNK, MAX_DYNAMIC_QA_PER_CHUNK))

        selected["target_q"] = target_q_values
        selected = selected.drop(columns=["chunk_len"], errors="ignore")

        logger.info(
            f"🧩 Coverage mode selected {len(selected)} chunks across {topic_count} topics | "
            f"target_rows={target_rows} | generation_target_rows={generation_target_rows} | "
            f"topic_budget={topic_budget} | max_dynamic_q_per_chunk={MAX_DYNAMIC_QA_PER_CHUNK}"
        )
        return selected

    def _write_topic_coverage_report(self, chunks_df: pd.DataFrame, rows: List[Dict[str, Any]]) -> None:
        """
        Writes topic coverage metadata without changing the final CSV schema.
        This helps production review verify which meaning-wise topics were covered.
        """
        try:
            report_path = os.path.join(self.output_dir, "topic_coverage.json")
            report: Dict[str, Any] = {
                "topic_discovery_enabled": TOPIC_DISCOVERY_ENABLED,
                "coverage_mode": COVERAGE_MODE,
                "min_qa_per_topic": MIN_QA_PER_TOPIC,
                "max_qa_per_topic": MAX_QA_PER_TOPIC,
                "max_dynamic_qa_per_chunk": MAX_DYNAMIC_QA_PER_CHUNK,
                "coverage_oversample_factor": COVERAGE_OVERSAMPLE_FACTOR,
                "topic_filter_text": TESTSET_TOPIC_FILTER_TEXT,
                "target_rows": self.target_rows,
                "max_rows": self.max_rows,
                "generated_rows_after_dedup": len(rows),
                "topics": [],
            }

            if not chunks_df.empty and "topic_id" in chunks_df.columns:
                for topic_id, topic_df in chunks_df.groupby("topic_id", dropna=False):
                    topic_name = None
                    if "topic_name" in topic_df.columns and not topic_df.empty:
                        topic_name = str(topic_df["topic_name"].iloc[0])

                    try:
                        topic_id_value = int(topic_id)
                    except Exception:
                        topic_id_value = str(topic_id)

                    confidence_series = topic_df.get("topic_confidence", pd.Series([0.0] * len(topic_df))).astype(float)
                    source_series = topic_df.get("source", pd.Series([], dtype=str)).astype(str)

                    report["topics"].append(
                        {
                            "topic_id": topic_id_value,
                            "topic_name": topic_name or "General topic",
                            "selected_chunks": int(len(topic_df)),
                            "avg_topic_confidence": float(confidence_series.mean()) if len(confidence_series) else 0.0,
                            "sources": sorted(set(source_series.tolist())),
                        }
                    )

            with open(report_path, "w", encoding="utf-8") as f:
                json.dump(report, f, indent=2, ensure_ascii=False)
            logger.info(f"🧭 Topic coverage report saved: {report_path}")
        except Exception as e:
            logger.warning(f"Could not write topic coverage report: {e}")

    def _generate_chunk_qas(self, idx, row):
        passage = str(row["chunk"])

        # In coverage mode the planner places target_q on each selected chunk.
        # This is what prevents small but dense documents from producing only 1-2 Q/A rows.
        target_q = row.get("target_q", None) if hasattr(row, "get") else None
        try:
            if target_q is None or pd.isna(target_q):
                target_q = self.estimate_coverage_questions(passage)
            target_q = int(target_q)
        except Exception:
            target_q = self.estimate_coverage_questions(passage)

        target_q = clamp(target_q, MIN_QA_PER_CHUNK, MAX_DYNAMIC_QA_PER_CHUNK if COVERAGE_MODE else MAX_QA_PER_CHUNK)

        prompt_text = self.prompt.format(
            content=passage,
            target_q=target_q,
        )

        data = self._parse_or_retry(
            prompt_text=prompt_text,
            passage_text=passage,
            chunk_idx=idx + 1,
            target_q=target_q,
        )

        if not data:
            return []

        pairs = self._normalize_dynamic_qas(data, max_q=target_q)
        if not pairs:
            return []

        src_hash = compute_text_hash(passage)

        rows = []
        for q, a in pairs:
            repaired = self._validate_and_repair_pair(q, a, passage, row)
            if repaired is None:
                continue

            rq, ra = repaired
            page_idx = coerce_page_idx(row.get("page_idx")) if hasattr(row, "get") else None
            source = row.get("source") if hasattr(row, "get") else None

            if is_page_idx_required_for_source(str(source)) and page_idx is None:
                self.rejected_pairs.append(
                    {
                        "question": rq,
                        "answer": ra,
                        "source": source,
                        "page_idx": page_idx,
                        "issues": ["missing_page_idx_for_pdf"],
                    }
                )
                continue

            rows.append(
                {
                    "question": rq,
                    "ground_truth": sanitize_ground_truth_text(ra),
                    "source": source,
                    "page_idx": page_idx,
                    "source_hash": src_hash,
                    "_passage": passage,
                }
            )
        return rows

    def generate_dataset(self, batch_size=25, max_workers=5) -> pd.DataFrame:
        logger.info("⚙️ No client dataset found. Starting domain-independent topic-aware generation...")

        chunks_df = self.chunker.load_chunks_df()
        logger.info(f"Total number of final chunks before topic discovery: {len(chunks_df)}")

        if chunks_df.empty:
            logger.warning("No chunks available. Returning empty dataset.")
            self.audit_logger.log(source_type="GENERATED")
            return ensure_dataset_schema(pd.DataFrame(columns=DATASET_COLUMNS))

        # Hard production cap. Final dataset will never cross 2000 rows.
        self.max_rows = min(self._env_int("TESTSET_MAX_ROWS", default=self.max_rows) or self.max_rows, 2000)
        self.target_rows = min(
            self._env_int("TESTSET_TARGET_ROWS", default=self.target_rows) or self.target_rows,
            self.max_rows,
            2000,
        )

        if TOPIC_DISCOVERY_ENABLED:
            chunks_df = self.topic_discoverer.assign_topics(chunks_df)

            if TESTSET_TOPIC_FILTER_TEXT:
                chunks_df = self.topic_discoverer.filter_by_user_topic(chunks_df, TESTSET_TOPIC_FILTER_TEXT)
                logger.info(
                    f"Chunks after semantic topic filter '{TESTSET_TOPIC_FILTER_TEXT}': {len(chunks_df)}"
                )

            if COVERAGE_MODE:
                chunks_df = self._build_coverage_plan(
                    chunks_df,
                    target_rows=self.target_rows,
                )
            elif TOPIC_BALANCED_GENERATION:
                chunks_df = self._select_dynamic_topic_balanced_chunks(
                    chunks_df,
                    target_rows=self.target_rows,
                )
        else:
            chunks_df = chunks_df.drop_duplicates(subset=["chunk_hash"] if "chunk_hash" in chunks_df.columns else ["chunk"])
            if COVERAGE_MODE:
                chunks_df = self._build_coverage_plan(
                    chunks_df,
                    target_rows=self.target_rows,
                )

        if chunks_df.empty:
            logger.warning("No chunks left after topic filtering/selection. Returning empty dataset.")
            self.audit_logger.log(source_type="GENERATED")
            return ensure_dataset_schema(pd.DataFrame(columns=DATASET_COLUMNS))

        logger.info(
            f"Final chunks selected for Q/A generation: {len(chunks_df)} | "
            f"target_rows={self.target_rows} | hard_max_rows={self.max_rows}"
        )

        rows: List[Dict[str, Any]] = []
        total = len(chunks_df)

        for start in range(0, total, batch_size):
            end = min(start + batch_size, total)
            logger.info(f"Processing chunk batch {start + 1}-{end}")

            batch = chunks_df.iloc[start:end]

            with ThreadPoolExecutor(max_workers=max_workers) as executor:
                futures = {
                    executor.submit(self._generate_chunk_qas, idx, row): idx
                    for idx, row in batch.iterrows()
                }

                for future in as_completed(futures):
                    try:
                        result_rows = future.result()
                        if result_rows:
                            rows.extend(result_rows)
                    except Exception as e:
                        logger.error(f"Chunk QA generation failed: {e}", exc_info=True)

                    if len(rows) >= self.max_rows:
                        logger.info(f"Reached hard TESTSET_MAX_ROWS={self.max_rows}. Stopping generation.")
                        break

            if len(rows) >= self.max_rows:
                break

        rows = self._deduplicate_generated_rows(rows)
        # Target rows is the normal production output size; max_rows is an absolute hard safety cap.
        final_cap = min(self.target_rows, self.max_rows, 2000)
        rows = rows[:final_cap]
        rows = [{k: v for k, v in r.items() if not str(k).startswith("_")} for r in rows]

        self._write_topic_coverage_report(chunks_df, rows)

        df = pd.DataFrame(rows, columns=DATASET_COLUMNS)
        self.audit_logger.log(source_type="GENERATED")
        return ensure_dataset_schema(df)

    def build_dataset(self, client_csv: Optional[str] = None) -> pd.DataFrame:
        client_path = (client_csv or "").strip()

        if client_path and os.path.exists(client_path):
            df = self.load_client_dataset(client_path)
        else:
            df = self.generate_dataset()

        df = ensure_dataset_schema(df)
        scores = self.quality_scorer.score(df)

        os.makedirs(self.output_dir, exist_ok=True)
        df.to_csv(self.output_csv, index=False)

        with open(os.path.join(self.output_dir, "quality_scores.json"), "w", encoding="utf-8") as f:
            json.dump(scores, f, indent=2)

        if self.rejected_pairs:
            rejected_path = os.path.join(self.output_dir, "rejected_qa_pairs.json")
            with open(rejected_path, "w", encoding="utf-8") as f:
                json.dump(self.rejected_pairs, f, indent=2, ensure_ascii=False)
            logger.info(f"🧪 Rejected Q/A report saved: {rejected_path} (rows={len(self.rejected_pairs)})")

        logger.info(f"✅ Final dataset saved: {self.output_csv} (rows={len(df)})")
        return df


# ============================
# OPTIONAL CLI
# ============================
if __name__ == "__main__":
    dataset_folder = os.getenv("DATASET_FOLDER", "data/uploads")
    auditor = os.getenv("AUDITOR", "client_123")
    client_path = os.getenv("CLIENT_DATASET", "").strip()

    manager = TestDatasetManager(auditor=auditor, dataset_folder=dataset_folder)
    df = manager.build_dataset(client_csv=client_path)
    print(df.head())
