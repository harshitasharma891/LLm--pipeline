LLM_CONFIG = {
    "provider": "vllm",
    "model": "nvidia/Nemotron-Mini-4B-Instruct",
    "temperature": 0.2,
    "base_url": "http://vllm:8000/v1"
}

