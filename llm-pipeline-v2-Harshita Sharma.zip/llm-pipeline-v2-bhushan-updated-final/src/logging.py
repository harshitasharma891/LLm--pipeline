"""
Logging module - re-exports logger from custom_logging
"""
from src.custom_logging import logger

__all__ = ["logger"]
