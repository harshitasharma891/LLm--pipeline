# src/license_execute.py

from truepy import License
from src.truepy_compat import patch_truepy_cryptography_api

import os
import datetime
import time
import ntplib
from src.logging import logger
from functools import wraps

# --- Custom Exception Classes ---
class LicenseError(Exception):
    """Base exception for license-related errors."""
    pass

class LicenseFileError(LicenseError):
    """Exception raised for errors in loading license or certificate files."""
    pass

class LicenseVerificationError(LicenseError):
    """Exception raised when license verification against certificate fails."""
    pass

class LicenseExpiredError(LicenseError):
    """Exception raised when the license has expired or is not yet valid."""
    pass

class NTPError(LicenseError):
    """Exception raised for issues with NTP server communication."""
    pass

# --- Helper for Retries ---
def retry(times: int, delay: float):
    """
    Decorator for retrying a function a specified number of times.
    """
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            last_exception = None

            for i in range(times):
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    last_exception = e
                    logger.warning(
                        f"Attempt {i + 1}/{times} of '{func.__name__}' failed: {e}. "
                        f"Retrying in {delay} seconds..."
                    )
                    time.sleep(delay)

            raise last_exception

        return wrapper

    return decorator


# --- Internet Time Function ---
@retry(times=3, delay=5)
def get_internet_time(
    ntp_server: str = "pool.ntp.org",
    timeout: float = 5.0
) -> datetime.datetime:
    """
    Fetches the current UTC time from an NTP server.
    """
    try:
        client = ntplib.NTPClient()
        response = client.request(ntp_server, version=3, timeout=timeout)

        # Use UTC time for license validation
        return datetime.datetime.utcfromtimestamp(response.tx_time)

    except ntplib.NTPException as e:
        raise NTPError(f"NTP server communication error: {e}")

    except OSError as e:
        raise NTPError(
            f"Network error during NTP request: {e}. Check internet connection."
        )

    except Exception as e:
        raise NTPError(f"An unexpected error occurred during NTP request: {e}")


# --- Main License Check Function ---
def check_license(
    license_dir: str = "./License",
    certificate_filename: str = "certificate.pem",
    license_filename: str = "license.key",
    secret_key: bytes = b"SP@tai_2024"
) -> bool:
    """
    Performs complete license validation.

    Steps:
        1. Load certificate.pem
        2. Load license.key
        3. Patch truepy for modern cryptography
        4. Verify license signature
        5. Check license validity period using NTP time
    """

    license_obj = None

    try:
        cert_path = os.path.join(license_dir, certificate_filename)
        license_path = os.path.join(license_dir, license_filename)

        # 1. Load certificate
        with open(cert_path, "rb") as f:
            certificate = f.read()

        logger.info(f"Loaded certificate from {cert_path}")

        # 2. Load license
        with open(license_path, "rb") as f:
            license_obj = License.load(f, secret_key)

        logger.info(f"Loaded license from {license_path}")

        # 3. Patch truepy for modern cryptography versions
        # This fixes: RSA object has no attribute 'verifier'
        patch_truepy_cryptography_api()

        # 4. Verify license signature using certificate
        license_obj.verify(certificate)

        logger.info("License signature verified against certificate successfully.")

    except FileNotFoundError as e:
        raise LicenseFileError(
            f"License file not found: {e.filename}. "
            f"Ensure '{license_dir}' contains "
            f"'{certificate_filename}' and '{license_filename}'."
        )

    except Exception as e:
        raise LicenseVerificationError(
            f"License integrity or verification failed: {e}. "
            f"Check truepy compatibility patch, cryptography version, "
            f"certificate.pem, license.key, and secret key."
        )

    if license_obj is None:
        raise LicenseVerificationError("License could not be loaded.")

    # 5. Check license time validity using internet time
    try:
        current_time = get_internet_time()
        logger.info(f"Current UTC time from NTP: {current_time}")

    except NTPError as e:
        logger.error(f"Failed to get internet time for license check: {e}")
        raise

    try:
        start_period = license_obj.data.not_before
        expiry_period = license_obj.data.not_after

        logger.info(f"License valid from: {start_period}")
        logger.info(f"License valid to: {expiry_period}")

    except AttributeError as e:
        raise LicenseVerificationError(
            f"License date fields are missing or invalid: {e}"
        )

    if start_period <= current_time < expiry_period:
        logger.info("Valid License! Application is authorized to run.")
        return True

    raise LicenseExpiredError(
        f"License is expired or not yet valid. "
        f"Current time: {current_time}. "
        f"Valid period: {start_period} to {expiry_period}."
    )